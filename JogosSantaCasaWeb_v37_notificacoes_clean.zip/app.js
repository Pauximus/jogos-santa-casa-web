window.APP_VERSION = "v37-notificacoes-clean";

const API = "https://jogos-santa-casa-api.onrender.com";
const BACKEND_API = "https://jogos-santa-casa-backend.onrender.com";
const SUPABASE_URL = "https://whnokdkqobtgyywqmrju.supabase.co";
const SUPABASE_KEY = "sb_publishable_t1ONYEGH_h11uFDENsINJw_RqlNxcpc";
const SUPABASE_HISTORICO = "historico_premios";
const SUPABASE_APOSTAS = "apostas_guardadas";

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
let logoutEmCurso = false;

const jogos = {
  euromilhoes: { nome: "Euromilhões", endpoint: "euromilhoes", numeros: 5, extras: 2, maxNum: 50, maxExtra: 12, extraLabel: "⭐", tab: "EUROMILHÕES", tipo: "numeros_extra" },
  totoloto: { nome: "Totoloto", endpoint: "totoloto", numeros: 5, extras: 1, maxNum: 49, maxExtra: 13, extraLabel: "Nº da Sorte", tab: "totoloto", tipo: "numeros_extra" },
  eurodreams: { nome: "EuroDreams", endpoint: "eurodreams", numeros: 6, extras: 1, maxNum: 40, maxExtra: 5, extraLabel: "Nº de Sonho", tab: "EURO★DREAMS", tipo: "numeros_extra" },
  milhao: { nome: "M1lhão", endpoint: "milhao", codigo: true, tab: "M1LHÃO", tipo: "codigo" },
  lotaria_classica: { nome: "Lotaria Clássica", endpoint: "lotaria_classica", lotaria: true, tab: "lotaria clássica", tipo: "lotaria" },
  lotaria_popular: { nome: "Lotaria Popular", endpoint: "lotaria_popular", lotaria: true, tab: "lotaria popular", tipo: "lotaria" }
};

const authBox = document.getElementById("authBox");
const userBox = document.getElementById("userBox");
const appBox = document.getElementById("appBox");
const authEmail = document.getElementById("authEmail");
const authPassword = document.getElementById("authPassword");
const authMsg = document.getElementById("authMsg");
const userInfo = document.getElementById("userInfo");
const syncInfo = document.getElementById("syncInfo");
const jogoSelect = document.getElementById("jogo");
const tabs = document.getElementById("tabs");
const camposDiv = document.getElementById("campos");
const listaApostas = document.getElementById("lista-apostas");
const resultado = document.getElementById("resultado");
const historicoDiv = document.getElementById("historico");
const estado = document.getElementById("estado");
const contadorApostas = document.getElementById("contadorApostas");
const statApostas = document.getElementById("statApostas");
const statPremios = document.getElementById("statPremios");
const statUltimoPremio = document.getElementById("statUltimoPremio");
const statJogoMaisPremiado = document.getElementById("statJogoMaisPremiado");
const pesquisaHistorico = document.getElementById("pesquisaHistorico");
const filtrosHistorico = document.getElementById("filtrosHistorico");
const dashboardResumo = document.getElementById("dashboardResumo");
const dashTotalApostas = document.getElementById("dashTotalApostas");
const dashTotalPremios = document.getElementById("dashTotalPremios");
const dashTaxaSucesso = document.getElementById("dashTaxaSucesso");
const dashUltimoPremio = document.getElementById("dashUltimoPremio");
const rankingJogos = document.getElementById("rankingJogos");
const rankingNota = document.getElementById("rankingNota");
const notificacaoPremio = document.getElementById("notificacaoPremio");
const notificacaoTitulo = document.getElementById("notificacaoTitulo");
const notificacaoTexto = document.getElementById("notificacaoTexto");
const fecharNotificacao = document.getElementById("fecharNotificacao");

let currentUser = null;
let aliasUtilizador = localStorage.getItem('jsc_alias_utilizador') || '';
let jogoAtual = "euromilhoes";
let apostas = {};
let historico = [];
let interfaceCriada = false;
let filtroHistorico = "todos";
let textoPesquisaHistorico = "";
let syncEmCurso = false;

for (const key of Object.keys(jogos)) apostas[key] = [];

function atualizarContador() {
  if (!contadorApostas) return;
  const n = apostas[jogoAtual]?.length || 0;
  const premios = historico?.length || 0;
  contadorApostas.textContent = `${n} aposta(s) · 🏆 ${premios} prémio(s)`;
  atualizarEstatisticas();
}

function nomeJogoCurto(nome) {
  const mapa = {
    "Euromilhões": "Euromilhões",
    "Totoloto": "Totoloto",
    "EuroDreams": "EuroDreams",
    "M1lhão": "M1lhão",
    "Lotaria Clássica": "Clássica",
    "Lotaria Popular": "Popular"
  };
  return mapa[nome] || nome || "—";
}

function normalizarDataSorteio(valor) {
  if (!valor) return "";
  const texto = String(valor).trim();

  // Se vier no formato DD/MM/AAAA, mantém simples e legível.
  const pt = texto.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (pt) {
    return `${pt[1].padStart(2, "0")}/${pt[2].padStart(2, "0")}/${pt[3]}`;
  }

  // Se vier em ISO ou Date parseável, converte para PT.
  const d = new Date(texto);
  if (!Number.isNaN(d.getTime())) {
    return d.toLocaleDateString("pt-PT");
  }

  return texto;
}

function mostrarNotificacaoPremio(eventos) {
  if (!notificacaoPremio || !eventos || !eventos.length) return;

  const primeiro = eventos[0];
  notificacaoTitulo.textContent = eventos.length === 1
    ? "🏆 Novo prémio encontrado!"
    : `🏆 ${eventos.length} novos prémios encontrados!`;

  notificacaoTexto.textContent = `${primeiro.jogo} · ${primeiro.premio} · ${primeiro.aposta}`;
  notificacaoPremio.style.display = "";

  window.clearTimeout(mostrarNotificacaoPremio._timer);
  mostrarNotificacaoPremio._timer = window.setTimeout(() => {
    notificacaoPremio.style.display = "none";
  }, 9000);
}

function premiosPorJogo() {
  const contagem = {};
  historico.forEach(h => {
    if (!h.jogo) return;
    contagem[h.jogo] = (contagem[h.jogo] || 0) + 1;
  });
  return contagem;
}

function atualizarBadgesTabs() {
  const contagem = premiosPorJogo();

  document.querySelectorAll(".tab").forEach(tab => {
    const key = tab.dataset.jogo;
    const cfg = jogos[key];
    if (!cfg) return;

    const total = contagem[cfg.nome] || 0;
    tab.innerHTML = `<span>${cfg.tab}</span>${total ? `<em>🏆${total}</em>` : ""}`;
  });
}

function dataCurta(texto) {
  if (!texto) return "";
  return String(texto).split(",")[0].trim();
}

function contagemPremiosPorJogo() {
  const contagem = {};
  historico.forEach(h => {
    const jogo = h.jogo || "—";
    contagem[jogo] = (contagem[jogo] || 0) + 1;
  });
  return contagem;
}

function atualizarDashboard() {
  const totalApostas = totalApostasGuardadas();
  const totalPremios = historico.length;
  const taxa = totalApostas ? Math.round((totalPremios / totalApostas) * 100) : 0;
  const ultimo = historico[0];

  if (dashTotalApostas) dashTotalApostas.textContent = totalApostas;
  if (dashTotalPremios) dashTotalPremios.textContent = totalPremios;
  if (dashTaxaSucesso) dashTaxaSucesso.textContent = `${taxa}%`;
  if (dashUltimoPremio) dashUltimoPremio.textContent = ultimo ? `${nomeJogoCurto(ultimo.jogo)}${ultimo.dataRegisto ? " · " + dataCurta(ultimo.dataRegisto) : ""}` : "—";

  if (dashboardResumo) {
    dashboardResumo.textContent = totalPremios
      ? `🏆 ${totalPremios} prémio(s) encontrados`
      : "Ainda sem prémios encontrados";
  }

  renderRankingJogos();
}

function renderRankingJogos() {
  if (!rankingJogos) return;

  const contagem = contagemPremiosPorJogo();
  const entradas = Object.entries(contagem).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "pt-PT"));
  const max = entradas[0]?.[1] || 0;

  if (!entradas.length) {
    rankingJogos.innerHTML = `<div class="ranking-empty">Ainda não há prémios no histórico.</div>`;
    if (rankingNota) rankingNota.textContent = "Sem dados";
    return;
  }

  if (rankingNota) rankingNota.textContent = `${entradas.length} jogo(s) com prémios`;

  rankingJogos.innerHTML = entradas.map(([jogo, total]) => {
    const percentagem = max ? Math.max(8, Math.round((total / max) * 100)) : 0;
    return `
      <div class="ranking-row">
        <div class="ranking-label">
          <span>${nomeJogoCurto(jogo)}</span>
          <strong>${total}</strong>
        </div>
        <div class="ranking-bar">
          <div style="width:${percentagem}%"></div>
        </div>
      </div>
    `;
  }).join("");
}

function totalApostasGuardadas() {
  return Object.values(apostas).reduce((total, lista) => total + (lista?.length || 0), 0);
}

function jogoMaisPremiado() {
  if (!historico.length) return "—";
  const contagem = {};
  historico.forEach(h => {
    const jogo = h.jogo || "—";
    contagem[jogo] = (contagem[jogo] || 0) + 1;
  });
  return Object.entries(contagem).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0], "pt-PT"))[0]?.[0] || "—";
}

function atualizarEstatisticas() {
  if (statApostas) statApostas.textContent = totalApostasGuardadas();
  if (statPremios) statPremios.textContent = historico.length;

  if (historico.length) {
    const ultimo = historico[0];
    if (statUltimoPremio) statUltimoPremio.textContent = ultimo.jogo ? `${ultimo.jogo}` : "—";
    if (statJogoMaisPremiado) statJogoMaisPremiado.textContent = jogoMaisPremiado();
  } else {
    if (statUltimoPremio) statUltimoPremio.textContent = "—";
    if (statJogoMaisPremiado) statJogoMaisPremiado.textContent = "—";
  }

  atualizarDashboard();
}

function filtrarHistorico() {
  let lista = [...historico];

  if (filtroHistorico !== "todos") {
    lista = lista.filter(h => (h.jogo || "").toLowerCase() === filtroHistorico.toLowerCase());
  }

  const q = textoPesquisaHistorico.trim().toLowerCase();
  if (q) {
    lista = lista.filter(h => [
      h.jogo,
      h.aposta,
      h.premio,
      h.sorteio,
      h.resultado,
      h.dataRegisto
    ].join(" ").toLowerCase().includes(q));
  }

  return lista;
}

function storageKey(nome) {
  return currentUser ? `${nome}_${currentUser.id}` : nome;
}

function mostrarAuthMensagem(texto, tipo = "warn") {
  authMsg.className = `result-card ${tipo}`;
  authMsg.textContent = texto;
  authMsg.style.display = "block";
}

function esconderAuthMensagem() {
  authMsg.style.display = "none";
}

function carregarLocal() {
  apostas = JSON.parse(localStorage.getItem(storageKey("apostasJSC")) || "{}");
  historico = JSON.parse(localStorage.getItem(storageKey("historicoJSC")) || "[]");
  for (const key of Object.keys(jogos)) {
    if (!apostas[key]) apostas[key] = [];
  }
}

function guardar() {
  localStorage.setItem(storageKey("apostasJSC"), JSON.stringify(apostas));
}

function guardarHistoricoLocal() {
  localStorage.setItem(storageKey("historicoJSC"), JSON.stringify(historico));
}


function agoraPt() {
  return new Date().toLocaleString("pt-PT");
}

function esperar(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function terminarEstadoPronto() {
  const cfg = jogos[jogoAtual];
  estado.textContent = `${cfg.nome}: ${apostas[jogoAtual]?.length || 0} aposta(s)`;
}

function comTimeout(promise, ms, descricao = "operação") {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${descricao} demorou demasiado tempo`)), ms);
  });

  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

async function fetchComTimeout(url, opcoes = {}, ms = 60000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);

  try {
    return await fetch(url, { ...opcoes, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function login() {
  esconderAuthMensagem();
  const email = authEmail.value.trim();
  const password = authPassword.value;

  if (!email || !password) {
    mostrarAuthMensagem("Preenche email e password.");
    return;
  }

  const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
  if (error) {
    mostrarAuthMensagem("Erro ao entrar: " + error.message, "bad");
    return;
  }

  currentUser = data.user;
  await arrancarApp();
}

async function criarConta() {
  esconderAuthMensagem();
  const email = authEmail.value.trim();
  const password = authPassword.value;

  if (!email || !password) {
    mostrarAuthMensagem("Preenche email e password.");
    return;
  }

  if (password.length < 6) {
    mostrarAuthMensagem("A password deve ter pelo menos 6 caracteres.");
    return;
  }

  const { data, error } = await supabaseClient.auth.signUp({
    email,
    password,
    options: { emailRedirectTo: "https://pauximus.github.io/jogos-santa-casa-web/" }
  });

  if (error) {
    mostrarAuthMensagem("Erro ao criar conta: " + error.message, "bad");
    return;
  }

  if (data.user && !data.session) {
    mostrarAuthMensagem("Conta criada. Confirma o email antes de entrar.", "warn");
    return;
  }

  currentUser = data.user;
  await arrancarApp();
}

async function recuperarPassword() {
  esconderAuthMensagem();
  const email = authEmail.value.trim();

  if (!email) {
    mostrarAuthMensagem("Escreve o email para recuperar a password.");
    return;
  }

  const { error } = await supabaseClient.auth.resetPasswordForEmail(email, {
    redirectTo: "https://pauximus.github.io/jogos-santa-casa-web/"
  });

  if (error) {
    mostrarAuthMensagem("Erro ao enviar recuperação: " + error.message, "bad");
    return;
  }

  mostrarAuthMensagem("Email de recuperação enviado. Verifica a caixa de entrada.", "warn");
}

async function logout() {
  logoutEmCurso = true;
  estado.textContent = "A terminar sessão...";

  const limparSessaoLocal = () => {
    try {
      // Limpa todos os dados locais da app e todos os tokens do Supabase.
      // As apostas/histórico continuam seguros na cloud, por utilizador.
      localStorage.clear();
      sessionStorage.clear();
    } catch (e) {
      console.warn("Não foi possível limpar storage local:", e);
    }
  };

  try {
    limparSessaoLocal();

    // Tenta terminar a sessão também no Supabase, mas não deixa a interface presa.
    await Promise.race([
      supabaseClient.auth.signOut({ scope: "global" }),
      new Promise(resolve => setTimeout(resolve, 3000))
    ]);
  } catch (err) {
    console.warn("Sign out remoto falhou/demorou; sessão local limpa na mesma:", err);
  } finally {
    currentUser = null;
    apostas = {};
    historico = [];
    for (const key of Object.keys(jogos)) apostas[key] = [];
    interfaceCriada = false;

    limparSessaoLocal();

    authBox.style.display = "";
    userBox.style.display = "none";
    appBox.style.display = "none";
    authEmail.value = "";
    authPassword.value = "";
    userInfo.textContent = "";
    syncInfo.textContent = "";
    estado.textContent = "Sessão terminada.";

    // Recarrega com cache-buster para impedir que o service worker/browser mantenha a sessão antiga.
    setTimeout(() => {
      const base = window.location.origin + window.location.pathname;
      window.location.replace(`${base}?logout=${Date.now()}`);
    }, 300);
  }
}

async function mostrarAppAutenticada() {
  authBox.style.display = "none";
  userBox.style.display = "";
  appBox.style.display = "";

  userInfo.textContent = `Olá, ${currentUser.email}`;
  carregarAliasCloud();
  syncInfo.textContent = "Sincronização automática ativa.";

  if (!interfaceCriada) {
    criarInterface();
    interfaceCriada = true;
  }

  renderCampos();
  renderLista();
  renderHistorico();
  atualizarDashboard();
  terminarEstadoPronto();
}

async function arrancarApp() {
  if (!currentUser) return;

  carregarLocal();
  mostrarAppAutenticada();

  // V24: a interface arranca imediatamente. Backend, apostas e histórico
  // sincronizam em segundo plano para nunca prender o ecrã.
  renderLista();
  renderHistorico();
  atualizarDashboard();
  terminarEstadoPronto();
  syncInfo.textContent = "Sincronização automática ativa.";

  setTimeout(() => {
    sincronizarTudo({ verificarDepois: true, background: true });
  }, 100);
}

async function sincronizarTudo(opcoes = {}) {
  if (!currentUser) return false;

  const verificarDepois = opcoes.verificarDepois === true;
  const background = opcoes.background === true;

  if (!background) estado.textContent = "A sincronizar...";
  syncInfo.textContent = "Sincronização em segundo plano...";

  try {
    // V24: nada bloqueia a interface. Backend, apostas e histórico correm em paralelo.
    const tarefas = await Promise.allSettled([
      atualizarResultadosBackend(),
      carregarApostasCloud(false),
      carregarHistoricoCloud(false)
    ]);

    tarefas.forEach((r, i) => {
      if (r.status === "rejected") console.warn("Sincronização parcial falhou:", i, r.reason);
    });

    renderLista();
    renderHistorico();
    atualizarDashboard();
    atualizarContador();
    atualizarBadgesTabs();

    if (verificarDepois) {
      if (!background) estado.textContent = "A verificar prémios...";
      await verificar().catch(err => console.warn("Verificação de prémios incompleta:", err));
    }

    syncInfo.textContent = `Última sincronização: ${agoraPt()}`;
    if (!background) estado.textContent = "Sincronização concluída.";
    return true;

  } catch (err) {
    console.warn("Sincronização incompleta:", err);
    syncInfo.textContent = `Última sincronização parcial: ${agoraPt()}`;
    return false;

  } finally {
    renderLista();
    renderHistorico();
    atualizarDashboard();
    atualizarContador();
    atualizarBadgesTabs();
    if (background) terminarEstadoPronto();
  }
}

async function carregarApostasCloud(chamarVerificar = true) {
  if (!currentUser) return;

  try {
    estado.textContent = "A sincronizar apostas...";

    const query = supabaseClient
      .from(SUPABASE_APOSTAS)
      .select("*")
      .eq("user_id", currentUser.id)
      .order("data_registo", { ascending: true })
      .limit(1000);

    const { data, error } = await query;

    if (error) throw error;

    const novasApostas = {};
    for (const key of Object.keys(jogos)) novasApostas[key] = [];

    (data || []).forEach(row => {
      if (novasApostas[row.jogo] && row.aposta && !novasApostas[row.jogo].includes(row.aposta)) {
        novasApostas[row.jogo].push(row.aposta);
      }
    });

    // Cloud é a fonte principal. LocalStorage fica só como cache.
    apostas = novasApostas;

    guardar();
    renderLista();
    atualizarDashboard();

    if (chamarVerificar) await verificar();
    return true;

  } catch (err) {
    console.warn("Apostas cloud indisponíveis:", err);
    estado.textContent = "Sincronização de apostas lenta. A usar dados locais.";
    renderLista();
    return false;
  }
}

async function apostaExisteNaCloud(jogo, aposta) {
  if (!currentUser) return false;

  const { data, error } = await supabaseClient
    .from(SUPABASE_APOSTAS)
    .select("id")
    .eq("user_id", currentUser.id)
    .eq("jogo", jogo)
    .eq("aposta", aposta)
    .limit(1);

  if (error) {
    console.warn(error);
    return false;
  }

  return (data || []).length > 0;
}

async function guardarApostaCloud(jogo, aposta) {
  if (!currentUser) {
    alert("Tens de iniciar sessão para guardar apostas na cloud.");
    return;
  }

  try {
    const existe = await apostaExisteNaCloud(jogo, aposta);
    if (existe) return;

    const { error } = await supabaseClient
      .from(SUPABASE_APOSTAS)
      .insert({ jogo, aposta, user_id: currentUser.id });

    if (error) throw error;

  } catch (err) {
    console.warn("Não foi possível guardar aposta na cloud:", err);
    alert("Não foi possível guardar a aposta na cloud: " + err.message);
  }
}

async function apagarApostaCloud(jogo, aposta) {
  if (!currentUser) return;

  try {
    const { error } = await supabaseClient
      .from(SUPABASE_APOSTAS)
      .delete()
      .eq("user_id", currentUser.id)
      .eq("jogo", jogo)
      .eq("aposta", aposta);

    if (error) throw error;

  } catch (err) {
    console.warn("Não foi possível apagar aposta na cloud:", err);
  }
}

function normalizarRegistoCloud(h) {
  return {
    idLocal: `cloud-${h.id}`,
    jogo: h.jogo || "",
    sorteio: h.sorteio || "último sorteio",
    dataSorteio: normalizarDataSorteio(h.data_sorteio || ""),
    aposta: h.aposta || "",
    resultado: h.acertos || "",
    premio: h.premio || "",
    dataRegisto: h.data_registo ? new Date(h.data_registo).toLocaleString("pt-PT") : ""
  };
}

async function carregarHistoricoCloud(chamarRender = true) {
  if (!currentUser) return;

  try {
    const query = supabaseClient
      .from(SUPABASE_HISTORICO)
      .select("*")
      .eq("user_id", currentUser.id)
      .order("data_registo", { ascending: false })
      .limit(200);

    const { data, error } = await query;

    if (error) throw error;

    historico = (data || []).map(normalizarRegistoCloud);
    guardarHistoricoLocal();

    if (chamarRender) renderHistorico();
    return true;

  } catch (err) {
    console.warn("Histórico cloud indisponível:", err);
    estado.textContent = "Sincronização de histórico lenta. A usar dados locais.";
    if (chamarRender) renderHistorico();
    return false;
  }
}

async function premioExisteNaCloud(ev) {
  if (!currentUser) return false;

  const { data, error } = await supabaseClient
    .from(SUPABASE_HISTORICO)
    .select("id")
    .eq("user_id", currentUser.id)
    .eq("jogo", ev.jogo)
    .eq("aposta", ev.aposta)
    .eq("premio", ev.premio)
    .eq("sorteio", ev.sorteio)
    .limit(1);

  if (error) {
    console.warn(error);
    return false;
  }

  return (data || []).length > 0;
}

async function guardarPremioCloud(ev) {
  if (!currentUser) return;

  try {
    const existe = await premioExisteNaCloud(ev);
    if (existe) return;

    const { error } = await supabaseClient
      .from(SUPABASE_HISTORICO)
      .insert({
        jogo: ev.jogo,
        aposta: ev.aposta,
        premio: ev.premio,
        sorteio: ev.sorteio,
        acertos: ev.resultado,
        data_sorteio: normalizarDataSorteio(ev.dataSorteio) || null,
        user_id: currentUser.id
      });

    if (error) throw error;

  } catch (err) {
    console.warn("Não foi possível guardar prémio na cloud:", err);
  }
}

function criarInterface() {
  jogoSelect.innerHTML = "";
  tabs.innerHTML = "";

  for (const [key, cfg] of Object.entries(jogos)) {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = cfg.nome;
    jogoSelect.appendChild(opt);

    const tab = document.createElement("button");
    tab.className = "tab " + key;
    tab.innerHTML = `<span>${cfg.tab}</span>`;
    tab.dataset.jogo = key;
    tab.onclick = () => mudarJogo(key);
    tabs.appendChild(tab);
  }

  mudarJogo(jogoAtual);
}

function mudarJogo(key) {
  jogoAtual = key;
  jogoSelect.value = key;
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.jogo === key));
  renderCampos();
  renderLista();
  verificar();
}

function renderCampos() {
  const cfg = jogos[jogoAtual];
  camposDiv.innerHTML = "";

  if (cfg.codigo) {
    camposDiv.innerHTML = '<label>Código:</label><input id="codigo" class="large" placeholder="ABC12345">';
    return;
  }

  if (cfg.lotaria) {
    camposDiv.innerHTML = '<label>Número:</label><input id="numeroLotaria" class="large" placeholder="Número">';
    return;
  }

  for (let i = 1; i <= cfg.numeros; i++) {
    camposDiv.insertAdjacentHTML("beforeend", `<label>Nº${i}:</label><input class="num" inputmode="numeric">`);
  }

  camposDiv.insertAdjacentHTML("beforeend", "<strong> + </strong>");

  for (let i = 1; i <= cfg.extras; i++) {
    const label = cfg.extraLabel === "⭐" ? `⭐ ${i}` : cfg.extraLabel;
    camposDiv.insertAdjacentHTML("beforeend", `<label>${label}:</label><input class="extra" inputmode="numeric">`);
  }
}

function normalizarAposta() {
  const cfg = jogos[jogoAtual];

  if (cfg.codigo) {
    return document.getElementById("codigo").value.trim().toUpperCase().replace(/\s+/g, "");
  }

  if (cfg.lotaria) {
    return document.getElementById("numeroLotaria").value.replace(/\D/g, "").padStart(5, "0");
  }

  const nums = [...document.querySelectorAll(".num")].map(i => i.value.trim());
  const extras = [...document.querySelectorAll(".extra")].map(i => i.value.trim());

  if (nums.some(v => !v) || extras.some(v => !v)) {
    alert("Preenche todos os campos.");
    return "";
  }

  const numsNum = nums.map(Number);
  const extrasNum = extras.map(Number);

  if (new Set(numsNum).size !== numsNum.length) {
    alert("Tens números repetidos.");
    return "";
  }

  if (new Set(extrasNum).size !== extrasNum.length) {
    alert("Tens extras repetidos.");
    return "";
  }

  if (numsNum.some(n => n < 1 || n > cfg.maxNum)) {
    alert(`Os números devem estar entre 1 e ${cfg.maxNum}.`);
    return "";
  }

  if (extrasNum.some(n => n < 1 || n > cfg.maxExtra)) {
    alert(`Os extras devem estar entre 1 e ${cfg.maxExtra}.`);
    return "";
  }

  return numsNum.sort((a,b) => a-b).join(" ") + " + " + extrasNum.sort((a,b) => a-b).join(" ");
}

function parseAposta(aposta) {
  const [numsTxt, extrasTxt] = aposta.split("+");
  return {
    nums: numsTxt.trim().split(/\s+/).map(Number),
    extras: extrasTxt ? extrasTxt.trim().split(/\s+/).map(Number) : []
  };
}

function renderLista() {
  listaApostas.innerHTML = "";
  atualizarContador();

  if (!apostas[jogoAtual] || !apostas[jogoAtual].length) {
    const li = document.createElement("li");
    li.innerHTML = `<span class="small">Ainda não há apostas guardadas neste jogo.</span>`;
    listaApostas.appendChild(li);
    return;
  }

  apostas[jogoAtual].forEach((aposta, index) => {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = `${index + 1}) ${aposta}`;

    const btn = document.createElement("button");
    btn.className = "delete";
    btn.textContent = "Apagar";
    btn.onclick = async () => {
      apostas[jogoAtual].splice(index, 1);
      guardar();
      await apagarApostaCloud(jogoAtual, aposta);
      renderLista();
      verificar();
    };

    li.appendChild(span);
    li.appendChild(btn);
    listaApostas.appendChild(li);
  });
}

async function adicionarAposta() {
  const aposta = normalizarAposta();
  if (!aposta) return;

  if (apostas[jogoAtual].includes(aposta)) {
    alert("Essa aposta já existe.");
    return;
  }

  apostas[jogoAtual].push(aposta);
  guardar();
  await guardarApostaCloud(jogoAtual, aposta);
  renderCampos();
  renderLista();
  verificar();
}

async function atualizarResultadosBackend() {
  try {
    estado.textContent = "A atualizar resultados oficiais...";
    const res = await fetchComTimeout(`${BACKEND_API}/atualizar`, { cache: "no-store" }, 70000);
    const data = await res.json().catch(() => ({}));
    if (data && data.ok === false) {
      
    } else {
      console.info("Atualização backend concluída.", data?.atualizado_em || "");
    }
    return data;
  } catch (err) {
    
    return null;
  }
}

function parseJsonPossivel(valor, fallback = null) {
  if (valor == null || valor === "") return fallback;
  if (typeof valor === "object") return valor;
  try { return JSON.parse(valor); } catch { return fallback; }
}

async function obterResultadosOficiaisBackend() {
  const res = await fetch(`${BACKEND_API}/resultados`, { cache: "no-store" });
  if (!res.ok) throw new Error(`Backend /resultados HTTP ${res.status}`);
  const data = await res.json();
  if (data.erro) throw new Error(data.erro);
  return data.resultados || data || [];
}

function linhaResultadoParaFormatoApp(row, cfg) {
  const premios = parseJsonPossivel(row.premios, cfg.lotaria ? [] : {});
  const dataSorteio = normalizarDataSorteio(row.data_sorteio || row.data || "");

  return {
    jogo: cfg.nome,
    sorteio: row.sorteio || "último sorteio",
    data: dataSorteio,
    numeros: converterParaArray(row.numeros),
    extras: converterParaArray(row.extras),
    codigo: row.codigo || "",
    premios: premios || (cfg.lotaria ? [] : {}),
    extra_nome: cfg.extraLabel === "⭐" ? "estrela" : cfg.extraLabel || "extra"
  };
}

function converterParaArray(valor) {
  if (Array.isArray(valor)) return valor.map(Number);
  if (typeof valor === "string") return valor.trim().split(/\s+/).map(Number);
  return [];
}

function categoriaTemPremio(jogo, n, e) {
  const map = {
    euromilhoes: new Set(["5+2","5+1","5+0","4+2","4+1","3+2","4+0","2+2","3+1","3+0","1+2","2+1","2+0"]),
    totoloto: new Set(["5+1","5+0","4+1","4+0","3+1","3+0","2+1"]),
    eurodreams: new Set(["6+1","6+0","5+1","5+0","4+1","4+0","3+1","2+1"])
  };
  return map[jogo]?.has(`${n}+${e}`) || false;
}

async function obterResultadoAtual() {
  const cfg = jogos[jogoAtual];

  try {
    const resultados = await obterResultadosOficiaisBackend();
    const row = resultados.find(r => r.jogo === jogoAtual);

    const temDados = row && (
      row.numeros || row.extras || row.codigo || row.premios || row.data_sorteio
    );

    if (temDados) {
      return linhaResultadoParaFormatoApp(row, cfg);
    }
  } catch (err) {
    console.info("Backend indisponível; a usar fallback/cache.");
  }

  const res = await fetch(`${API}/${cfg.endpoint}`, { cache: "no-store" });
  const data = await res.json();
  if (data.erro) throw new Error(data.erro);
  return data;
}

async function verificar() {
  if (!currentUser) return;

  const cfg = jogos[jogoAtual];
  estado.textContent = "A obter resultados...";

  try {
    const data = await obterResultadoAtual();
    let eventos = [];

    if (cfg.tipo === "numeros_extra") eventos = renderResultadoNumerosExtra(data);
    else if (cfg.tipo === "codigo") eventos = renderResultadoCodigo(data);
    else if (cfg.tipo === "lotaria") eventos = renderResultadoLotaria(data);

    await guardarEventosHistorico(data, eventos);
    estado.textContent = `${cfg.nome}: ${apostas[jogoAtual].length} aposta(s)`;

  } catch (err) {
    resultado.innerHTML = `<div class="result-card bad">Erro ao obter resultados: ${err.message}</div>`;
    estado.textContent = "Erro.";
  }
}

function renderCabecalhoResultado(data, conteudo) {
  return `
    <div class="result-title">${data.jogo.toUpperCase()}</div>
    <div class="result-meta">
      <div>Sorteio: ${data.sorteio || "último sorteio"}</div>
      <div>Data: ${data.data || ""}</div>
      ${conteudo}
    </div>
  `;
}

function renderResultadoNumerosExtra(data) {
  const numeros = converterParaArray(data.numeros);
  const extras = converterParaArray(data.extras);
  const eventos = [];

  let html = renderCabecalhoResultado(data, `<div>Resultado: [${numeros.join(", ")}] + [${extras.join(", ")}]</div>`);

  if (!apostas[jogoAtual].length) html += `<div class="result-card warn">Sem apostas guardadas.</div>`;

  apostas[jogoAtual].forEach((aposta, index) => {
    const { nums, extras: apostaExtras } = parseAposta(aposta);
    const acertosNums = nums.filter(n => numeros.includes(n)).length;
    const acertosExtras = apostaExtras.filter(e => extras.includes(e)).length;
    const categoria = `${acertosNums}+${acertosExtras}`;
    const premioInfo = data.premios ? data.premios[categoria] : null;
    const premiado = !!premioInfo || categoriaTemPremio(jogoAtual, acertosNums, acertosExtras);
    const comAcertos = acertosNums || acertosExtras;

    let titulo = "🔴 SEM PRÉMIO";
    let classe = "bad";
    let premio = "";
    let valor = "";

    if (premiado) {
      premio = premioInfo?.premio || "Prémio";
      valor = premioInfo?.valor || "valor a consultar";
      titulo = `🏆 PREMIADO — ${premio} — ${valor}`;
      classe = "ok";
    } else if (comAcertos) {
      titulo = "🟡 COM ACERTOS — sem prémio";
      classe = "warn";
    }

    if (premiado) {
      eventos.push({
        jogo: data.jogo,
        aposta,
        resultado: `${acertosNums} número(s) + ${acertosExtras} ${data.extra_nome || "extra"}(s)`,
        sorteio: data.sorteio || "último sorteio",
        dataSorteio: data.data || "",
        premio: `${premio} — ${valor}`
      });
    }

    html += `
      <div class="result-card ${classe}">
        <strong>${titulo}</strong><br>
        Aposta ${index + 1}: ${aposta}<br>
        Acertos: ${acertosNums} número(s) + ${acertosExtras} ${data.extra_nome || "extra"}(s)
      </div>`;
  });

  resultado.innerHTML = html;
  return eventos;
}

function renderResultadoCodigo(data) {
  const codigoResultado = (data.codigo || "").replace(/\s+/g, "").toUpperCase();
  const eventos = [];

  let html = renderCabecalhoResultado(data, `<div>Resultado: ${codigoResultado || "não encontrado"}</div>`);

  if (!apostas[jogoAtual].length) html += `<div class="result-card warn">Sem códigos guardados.</div>`;

  apostas[jogoAtual].forEach((aposta, index) => {
    const codigo = aposta.replace(/\s+/g, "").toUpperCase();
    const premiado = codigo && codigo === codigoResultado;

    if (premiado) {
      eventos.push({
        jogo: data.jogo,
        aposta,
        resultado: codigoResultado,
        sorteio: data.sorteio || "último sorteio",
        dataSorteio: data.data || "",
        premio: "M1lhão — valor a consultar"
      });
    }

    html += `
      <div class="result-card ${premiado ? "ok" : "bad"}">
        <strong>${premiado ? "🏆 PREMIADO" : "🔴 SEM PRÉMIO"}</strong><br>
        Código ${index + 1}: ${aposta}
      </div>`;
  });

  resultado.innerHTML = html;
  return eventos;
}

function renderResultadoLotaria(data) {
  const premios = data.premios || [];
  const numerosPremiados = premios.map(p => String(p.numero).padStart(5, "0"));
  const eventos = [];

  let listaPremios = premios.map(p => `${p.premio}: ${p.numero}`).join("<br>");
  let html = renderCabecalhoResultado(data, `<div>${listaPremios || "Prémios não encontrados"}</div>`);

  if (!apostas[jogoAtual].length) html += `<div class="result-card warn">Sem números guardados.</div>`;

  apostas[jogoAtual].forEach((aposta, index) => {
    const numero = String(aposta).padStart(5, "0");
    const pos = numerosPremiados.indexOf(numero);
    const premiado = pos >= 0;
    const premio = premiado ? premios[pos].premio : "";

    if (premiado) {
      eventos.push({
        jogo: data.jogo,
        aposta: numero,
        resultado: numero,
        sorteio: data.sorteio || "último sorteio",
        dataSorteio: data.data || "",
        premio
      });
    }

    html += `
      <div class="result-card ${premiado ? "ok" : "bad"}">
        <strong>${premiado ? `🏆 PREMIADO — ${premio}` : "🔴 SEM PRÉMIO"}</strong><br>
        Número ${index + 1}: ${numero}
      </div>`;
  });

  resultado.innerHTML = html;
  return eventos;
}

async function guardarEventosHistorico(data, eventos) {
  if (!eventos.length) {
    renderHistorico();
    return;
  }

  const novosEventos = [];

  for (const ev of eventos) {
    const idLocal = `${ev.jogo}|${ev.sorteio}|${ev.aposta}|${ev.premio}|${ev.resultado}`;
    const existeLocal = historico.some(h => h.idLocal === idLocal);

    if (!existeLocal) {
      const registo = {
        idLocal,
        jogo: ev.jogo,
        sorteio: ev.sorteio,
        dataSorteio: normalizarDataSorteio(ev.dataSorteio) || "",
        aposta: ev.aposta,
        resultado: ev.resultado,
        premio: ev.premio,
        dataRegisto: new Date().toLocaleString("pt-PT")
      };

      historico.unshift(registo);
      novosEventos.push(registo);
      await guardarPremioCloud(ev);
    }
  }

  historico = historico.slice(0, 200);
  guardarHistoricoLocal();

  if (novosEventos.length) {
    mostrarNotificacaoPremio(novosEventos);
  }

  await carregarHistoricoCloud();
}

function renderHistorico() {
  atualizarEstatisticas();
  atualizarContador();
  atualizarBadgesTabs();

  const lista = filtrarHistorico();

  if (!historico.length) {
    historicoDiv.innerHTML = `<div class="result-card warn">Ainda não há prémios guardados no histórico.</div>`;
    return;
  }

  if (!lista.length) {
    historicoDiv.innerHTML = `<div class="result-card warn">Nenhum registo encontrado com os filtros atuais.</div>`;
    return;
  }

  historicoDiv.innerHTML = lista.map(h => `
    <div class="history-item">
      <div class="history-item-head">
        <strong>🏆 ${h.jogo} — ${h.premio}</strong>
        <span class="history-badge">${h.dataRegisto || ""}</span>
      </div>
      <div>Sorteio: ${h.sorteio}${h.dataSorteio ? " — " + h.dataSorteio : ""}</div>
      <div>Aposta: ${h.aposta}</div>
      <div>Acertos/resultado: ${h.resultado}</div>
    </div>`).join("");
}





function obterNomeRelatorio() {
  const nome = (aliasUtilizador || localStorage.getItem("jsc_alias_utilizador") || "").trim();
  return nome || "Utilizador";
}

function atualizarCampoAlias() {
  const input = document.getElementById("aliasUtilizador");
  if (input) input.value = aliasUtilizador || "";
}

async function carregarAliasCloud() {
  atualizarCampoAlias();

  if (!supabaseClient || !currentUser) return;

  try {
    const { data, error } = await supabaseClient
      .from("perfis_utilizador")
      .select("nome_relatorio")
      .eq("user_id", currentUser.id)
      .maybeSingle();

    if (!error && data?.nome_relatorio) {
      aliasUtilizador = data.nome_relatorio;
      localStorage.setItem("jsc_alias_utilizador", aliasUtilizador);
      atualizarCampoAlias();
    }
  } catch (err) {
    // A app continua a funcionar: o nome fica guardado localmente.
    console.info("Nome/alcunha: a usar valor local.");
  }
}






function mostrarFeedbackAlias(msg) {
  const el = document.getElementById("aliasFeedback");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("visivel");
  clearTimeout(window.__aliasFeedbackTimer);
  window.__aliasFeedbackTimer = setTimeout(() => {
    el.textContent = "";
    el.classList.remove("visivel");
  }, 2500);
}

function normalizarJogoV33(nome) {
  const raw = String(nome || "").toLowerCase().trim()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9_ -]/g, "");
  if (!raw) return "";
  if (raw.includes("eurom")) return "euromilhoes";
  if (raw.includes("toto")) return "totoloto";
  if (raw.includes("dream")) return "eurodreams";
  if (raw.includes("milhao") || raw.includes("m1lhao")) return "milhao";
  if (raw.includes("class")) return "lotaria_classica";
  if (raw.includes("popular")) return "lotaria_popular";
  return raw.replace(/\s+/g, "_");
}

function formatarJogoV33(nome) {
  const key = normalizarJogoV33(nome);
  const map = { euromilhoes: "Euromilhões", totoloto: "Totoloto", eurodreams: "EuroDreams", milhao: "M1lhão", lotaria_classica: "Lotaria Clássica", lotaria_popular: "Lotaria Popular" };
  return map[key] || nome || "—";
}

function parseJsonV33(valor, fallback) { try { return valor ? JSON.parse(valor) : fallback; } catch { return fallback; } }

function recolherApostasV33() {
  const out=[]; const seen=new Set();
  function add(lista){ if(!Array.isArray(lista)) return; lista.forEach(item=>{ if(!item) return; const key=JSON.stringify(item); if(seen.has(key)) return; seen.add(key); out.push(item); }); }
  try { if (Array.isArray(apostas)) add(apostas); } catch {}
  if (Array.isArray(window.apostas)) add(window.apostas);
  if (Array.isArray(window.apostasGuardadas)) add(window.apostasGuardadas);
  for (let i=0;i<localStorage.length;i++){
    const k=localStorage.key(i); if(!k || !k.toLowerCase().includes("aposta")) continue;
    const p=parseJsonV33(localStorage.getItem(k), null);
    if(Array.isArray(p)) add(p); else if(p && typeof p==="object") Object.values(p).forEach(v=>Array.isArray(v)&&add(v));
  }
  return out;
}

function recolherHistoricoV33() {
  const all=[]; const seen=new Set();
  function add(lista){ if(!Array.isArray(lista)) return; lista.forEach(item=>{ if(!item) return; const key=JSON.stringify(item); if(seen.has(key)) return; seen.add(key); all.push(item); }); }
  try { if (Array.isArray(historico)) add(historico); } catch {}
  if (Array.isArray(window.historico)) add(window.historico);
  ["historico","jsc_historico","historico_premios","premios_historico","historicoPremios"].forEach(k=>{ const p=parseJsonV33(localStorage.getItem(k), null); if(Array.isArray(p)) add(p); });
  return all;
}

function obterCampoJogoPremioV33(item) { return item?.jogo || item?.tipo || item?.game || item?.nomeJogo || item?.lottery || item?.endpoint || item?.titulo || item?.descricao || ""; }
function jogoDaApostaV33(aposta) { const direto=aposta?.jogo||aposta?.tipo||aposta?.game||aposta?.nomeJogo||aposta?.lottery||aposta?.endpoint; if(direto) return normalizarJogoV33(direto); try { return normalizarJogoV33(jogoAtual || document.querySelector("select")?.value || ""); } catch { return ""; } }
function contarApostasPorJogoV33(){ const c={}; recolherApostasV33().forEach(a=>{ const jogo=jogoDaApostaV33(a); if(!jogo) return; c[jogo]=(c[jogo]||0)+1; }); return c; }
function contarPremiosPorJogoV33(){ const c={}; recolherHistoricoV33().forEach(h=>{ const jogo=normalizarJogoV33(obterCampoJogoPremioV33(h)); if(!jogo) return; c[jogo]=(c[jogo]||0)+1; }); if(!Object.keys(c).length && typeof contagemPremiosPorJogo==="function"){ try{return contagemPremiosPorJogo()||{};}catch{} } return c; }
function maiorEntradaV33(obj){ const e=Object.entries(obj||{}); if(!e.length) return null; return e.sort((a,b)=>b[1]-a[1] || String(a[0]).localeCompare(String(b[0]),"pt-PT"))[0]; }
function valorPremioV33(item){ const t=String(item?.valor||item?.premio||item?.descricao||item?.titulo||""); const m=t.match(/(\d{1,3}(?:[.\s]\d{3})*(?:,\d{2})|\d+(?:,\d{2})?)/g); if(!m) return 0; return Math.max(...m.map(x=>Number(x.replace(/\s/g,"").replace(/\./g,"").replace(",","."))||0)); }
function maiorPremioV33(){ const h=recolherHistoricoV33(); if(!h.length) return null; return [...h].sort((a,b)=>valorPremioV33(b)-valorPremioV33(a))[0]; }
function gerarSequenciaV33(totalApostas,historicoLista){ const totalPremios=historicoLista.length; const tamanho=Math.min(Math.max(totalApostas,totalPremios),10); if(!tamanho) return []; return Array.from({length:tamanho},(_,i)=>i>=tamanho-totalPremios); }
function maiorSeqV33(seq,valor){ let melhor=0, atual=0; seq.forEach(v=>{ if(v===valor){ atual++; melhor=Math.max(melhor,atual); } else atual=0; }); return melhor; }
function atualizarSequenciaVisualV33(totalApostas,historicoLista){ const el=document.getElementById("statSequenciaVisual"); const resumo=document.getElementById("statMaiorSequencia"); if(!el) return; const seq=gerarSequenciaV33(totalApostas,historicoLista); const maiorPremios=maiorSeqV33(seq,true); const maiorSem=maiorSeqV33(seq,false); if(resumo) resumo.textContent = maiorPremios ? `${maiorPremios} prémio(s) seguidos` : `${maiorSem} sem prémio`; if(!seq.length){ el.innerHTML='<span class="sequencia-vazia">Sem dados suficientes</span>'; return; } el.innerHTML=seq.map((ganhou,idx)=>`<span class="seq-chip ${ganhou?"win":"lose"}" title="${idx+1}: ${ganhou?"Prémio":"Sem prémio"}">${ganhou?"🏆":"❌"}</span>`).join(""); }
function atualizarConquistasV33(totalApostas,totalPremios,maiorPremios){ const grid=document.getElementById("conquistasGrid"); const resumo=document.getElementById("statConquistasResumo"); if(!grid) return; const conquistas=[{ok:totalPremios>=1,icon:"🥇",title:"Primeiro prémio",desc:"Encontraste o primeiro prémio."},{ok:totalApostas>=10,icon:"🎯",title:"10 apostas",desc:"Registaste 10 apostas."},{ok:totalApostas>=50,icon:"📈",title:"50 apostas",desc:"Utilização consistente."},{ok:totalPremios>=5,icon:"💰",title:"5 prémios",desc:"Cinco prémios registados."},{ok:maiorPremios>=2,icon:"🔥",title:"Sequência",desc:"Dois prémios seguidos."},{ok:totalPremios>=10,icon:"🏆",title:"10 prémios",desc:"Histórico forte."}]; const desbloqueadas=conquistas.filter(c=>c.ok).length; if(resumo) resumo.textContent=`${desbloqueadas}/${conquistas.length}`; grid.innerHTML=conquistas.map(c=>`<div class="conquista ${c.ok?"ok":"locked"}"><b>${c.icon}</b><div><strong>${c.title}</strong><span>${c.ok?"Desbloqueada":c.desc}</span></div></div>`).join(""); }
function atualizarEstatisticasAvancadas(){ const historicoLista=recolherHistoricoV33(); const porApostas=contarApostasPorJogoV33(); const porPremios=contarPremiosPorJogoV33(); const totalApostas=Object.values(porApostas).reduce((s,n)=>s+n,0); const totalPremios=Object.values(porPremios).reduce((s,n)=>s+n,0); const maisApostado=maiorEntradaV33(porApostas); const maisPremiado=maiorEntradaV33(porPremios); const maior=maiorPremioV33(); const seq=gerarSequenciaV33(totalApostas,historicoLista); const maiorPremios=maiorSeqV33(seq,true); const setTxt=(id,txt)=>{ const el=document.getElementById(id); if(el) el.textContent=txt; }; setTxt("statJogoMaisApostado", maisApostado?`${formatarJogoV33(maisApostado[0])} (${maisApostado[1]})`:"—"); setTxt("statJogoMaisPremiado", maisPremiado?`${formatarJogoV33(maisPremiado[0])} (${maisPremiado[1]})`:"—"); if(maior){ const valor=valorPremioV33(maior); setTxt("statMelhorPremio", `${formatarJogoV33(obterCampoJogoPremioV33(maior))}${valor?" — "+valor.toLocaleString("pt-PT",{style:"currency",currency:"EUR"}):""}`); } else setTxt("statMelhorPremio","—"); setTxt("statUltimaSync", `${Math.max(0,totalApostas-totalPremios)} aposta(s)`); atualizarSequenciaVisualV33(totalApostas,historicoLista); atualizarConquistasV33(totalApostas,totalPremios,maiorPremios); const ranking=document.getElementById("statRankingJogos"); const resumo=document.getElementById("statResumoRanking"); const entradas=Object.entries(porPremios).sort((a,b)=>b[1]-a[1]); if(resumo) resumo.textContent=totalPremios?`${totalPremios} prémio(s) em ${entradas.length} jogo(s)`:"Sem dados"; if(!ranking) return; if(!entradas.length){ ranking.innerHTML='<div class="mini-ranking-empty">Ainda não há prémios suficientes para estatísticas.</div>'; return; } const max=Math.max(...entradas.map(([,n])=>n),1); ranking.innerHTML=entradas.map(([jogo,total],idx)=>{ const pct=Math.max(8,Math.round((total/max)*100)); return `<div class="mini-ranking-row"><div class="mini-ranking-label"><span>${idx+1}.º ${formatarJogoV33(jogo)}</span><strong>${total}</strong></div><div class="mini-ranking-bar"><i style="width:${pct}%"></i></div></div>`; }).join(""); }
async function pedirPermissaoNotificacoes(){ if(!("Notification" in window)){ alert("Este browser não suporta notificações."); return; } const perm=await Notification.requestPermission(); localStorage.setItem("jsc_notificacoes", perm==="granted"?"1":"0"); const btn=document.getElementById("ativarNotificacoesBtn"); if(btn) btn.textContent=perm==="granted"?"🔔 Ativas":"🔔 Notificações"; if(perm==="granted") new Notification("Notificações ativas",{body:"Vais poder receber alertas quando a app encontrar prémios.",icon:"icon-192.png"}); }
function notificarPremiosSeNecessarioV33(){ if(!("Notification" in window)||Notification.permission!=="granted") return; if(localStorage.getItem("jsc_notificacoes")!=="1") return; const historicoLista=recolherHistoricoV33(); const totalPremios=historicoLista.length; const ultimoAvisado=Number(localStorage.getItem("jsc_premios_notificados")||"0"); if(totalPremios>ultimoAvisado){ const ultimo=historicoLista[0]||historicoLista[historicoLista.length-1]||{}; new Notification("Prémio encontrado!",{body:`${formatarJogoV33(obterCampoJogoPremioV33(ultimo))}: ${ultimo.premio||"prémio registado"}`,icon:"icon-192.png"}); localStorage.setItem("jsc_premios_notificados",String(totalPremios)); } }
function iniciarNotificacoesV33(){ const btn=document.getElementById("ativarNotificacoesBtn"); if(!btn) return; if("Notification" in window && Notification.permission==="granted" && localStorage.getItem("jsc_notificacoes")==="1") btn.textContent="🔔 Ativas"; btn.addEventListener("click",()=>pedirPermissaoNotificacoes()); }

async function guardarAliasUtilizador() {
  const input = document.getElementById("aliasUtilizador");
  const novoNome = (input?.value || "").trim().slice(0, 40);

  aliasUtilizador = novoNome;
  if (novoNome) {
    localStorage.setItem("jsc_alias_utilizador", novoNome);
  } else {
    localStorage.removeItem("jsc_alias_utilizador");
  }

  atualizarCampoAlias();

  if (supabaseClient && currentUser) {
    try {
      const { error } = await supabaseClient
        .from("perfis_utilizador")
        .upsert({
          user_id: currentUser.id,
          nome_relatorio: novoNome || null,
          atualizado_em: new Date().toISOString()
        }, { onConflict: "user_id" });

      if (!error) {
        estado.textContent = "Nome do relatório guardado.";
        mostrarFeedbackAlias("Nome guardado com sucesso.");
        return;
      }
    } catch (err) {
      // Sem problema: fica local.
    }
  }

  estado.textContent = "Nome guardado neste dispositivo.";
  mostrarFeedbackAlias("Nome guardado com sucesso.");
}

function historicoParaRelatorioOrdenado() {
  return [...historico].sort((a, b) => {
    const da = a.dataRegisto ? new Date(a.dataRegisto).getTime() : 0;
    const db = b.dataRegisto ? new Date(b.dataRegisto).getTime() : 0;
    return db - da;
  });
}

function nomeFicheiroPdfHistorico() {
  const hoje = new Date().toISOString().slice(0, 10);
  return `historico_premios_jogos_santa_casa_${hoje}.pdf`;
}

function gerarTextoPartilhaHistorico() {
  const totalApostas = totalApostasGuardadas();
  const totalPremios = historico.length;
  const taxa = totalApostas ? Math.round((totalPremios / totalApostas) * 100) : 0;

  const linhas = [
    "🍀 Verificador Jogos Santa Casa",
    "",
    `Utilizador: ${obterNomeRelatorio()}`,
    `Data: ${new Date().toLocaleString("pt-PT")}`,
    "",
    `Apostas guardadas: ${totalApostas}`,
    `Prémios encontrados: ${totalPremios}`,
    `Taxa de sucesso: ${taxa}%`,
    "",
    "Histórico de prémios:"
  ];

  if (!historico.length) {
    linhas.push("Sem prémios registados.");
  } else {
    historicoParaRelatorioOrdenado().slice(0, 20).forEach((h, i) => {
      linhas.push("");
      linhas.push(`${i + 1}. ${h.jogo || "—"} — ${h.premio || "—"}`);
      linhas.push(`Sorteio: ${h.sorteio || "—"}${h.dataSorteio ? " — " + h.dataSorteio : ""}`);
      linhas.push(`Aposta: ${h.aposta || "—"}`);
      linhas.push(`Resultado: ${h.resultado || "—"}`);
    });
  }

  linhas.push("");
  linhas.push("https://pauximus.github.io/jogos-santa-casa-web/");
  return linhas.join("\n");
}

function obterClasseJsPdf() {
  if (window.jspdf && window.jspdf.jsPDF) return window.jspdf.jsPDF;
  if (window.jsPDF) return window.jsPDF;
  return null;
}

function gerarPdfHistoricoBlobOuDoc() {
  const JsPDF = obterClasseJsPdf();
  if (!JsPDF) {
    alert("O gerador de PDF ainda não carregou. Tenta novamente dentro de alguns segundos.");
    return null;
  }

  if (!historico.length) {
    alert("Não existem prémios no histórico para exportar.");
    return null;
  }

  const doc = new JsPDF({ unit: "mm", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 14;
  const contentW = pageW - margin * 2;
  let y = 16;

  function footer() {
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text("Gerado por Verificador Jogos Santa Casa", margin, pageH - 8);
    doc.setTextColor(0);
  }

  function pageBreakIfNeeded(extra) {
    if (y + extra > pageH - 16) {
      doc.addPage();
      y = 16;
      footer();
    }
  }

  const totalApostas = totalApostasGuardadas();
  const totalPremios = historico.length;
  const taxa = totalApostas ? Math.round((totalPremios / totalApostas) * 100) : 0;
  const ultimo = historico[0];

  doc.setFillColor(232, 247, 238);
  doc.roundedRect(margin, y, contentW, 32, 4, 4, "F");
  doc.setTextColor(23, 99, 58);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text("Relatório de Prémios", margin + 5, y + 11);
  doc.setFontSize(10);
  doc.setTextColor(60);
  doc.text(`Utilizador: ${obterNomeRelatorio()}`, margin + 5, y + 20);
  doc.text(`Data: ${new Date().toLocaleString("pt-PT")}`, margin + 5, y + 26);
  y += 42;

  doc.setTextColor(0);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text("Resumo", margin, y);
  y += 8;

  const cards = [
    ["Apostas", totalApostas],
    ["Prémios", totalPremios],
    ["Taxa", `${taxa}%`],
    ["Último", ultimo?.jogo || "—"]
  ];

  const cardW = (contentW - 9) / 4;
  cards.forEach((c, i) => {
    const x = margin + i * (cardW + 3);
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(x, y, cardW, 22, 3, 3, "F");
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(100);
    doc.text(c[0], x + 3, y + 7);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(0);
    doc.text(String(c[1]).slice(0, 18), x + 3, y + 16);
  });
  y += 32;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text("Histórico de prémios", margin, y);
  y += 8;

  historicoParaRelatorioOrdenado().forEach((h, i) => {
    pageBreakIfNeeded(44);

    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(223, 229, 236);
    doc.roundedRect(margin, y, contentW, 39, 3, 3, "FD");

    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(23, 99, 58);
    doc.text(`${i + 1}. ${h.jogo || "—"} — ${h.premio || "—"}`, margin + 4, y + 8);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(45);
    doc.text(`Sorteio: ${h.sorteio || "—"}${h.dataSorteio ? " — " + h.dataSorteio : ""}`, margin + 4, y + 15);
    doc.text(`Aposta: ${h.aposta || "—"}`, margin + 4, y + 22);
    doc.text(`Acertos/resultado: ${h.resultado || "—"}`, margin + 4, y + 29);
    doc.text(`Guardado em: ${h.dataRegisto || "—"}`, margin + 4, y + 36);

    y += 45;
  });

  footer();
  return { doc, nome: nomeFicheiroPdfHistorico() };
}

function exportarPdfHistorico() {
  const pdf = gerarPdfHistoricoBlobOuDoc();
  if (!pdf) return;
  pdf.doc.save(pdf.nome);
  estado.textContent = "PDF exportado.";
}

async function partilharHistorico() {
  if (!historico.length) {
    alert("Não existem prémios no histórico para partilhar.");
    return;
  }

  const texto = gerarTextoPartilhaHistorico();

  try {
    const pdf = gerarPdfHistoricoBlobOuDoc();

    if (pdf && navigator.canShare) {
      const blob = pdf.doc.output("blob");
      const file = new File([blob], pdf.nome, { type: "application/pdf" });

      if (navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: "Histórico de prémios",
          text: "Segue o meu histórico de prémios.",
          files: [file]
        });
        estado.textContent = "Histórico partilhado.";
        return;
      }
    }

    if (navigator.share) {
      await navigator.share({
        title: "Histórico de prémios",
        text: texto
      });
      estado.textContent = "Histórico partilhado.";
      return;
    }
  } catch (err) {
    console.warn("Partilha cancelada ou indisponível:", err);
    return;
  }

  const pdfFallback = gerarPdfHistoricoBlobOuDoc();
  if (pdfFallback) {
    pdfFallback.doc.save(pdfFallback.nome);
    alert("A partilha direta não está disponível neste dispositivo. O PDF foi transferido para poderes enviar por WhatsApp, email ou outra app.");
  }
}


async function limparHistorico() {
  const mensagem = currentUser
    ? "Queres mesmo apagar TODO o teu histórico de prémios?\n\nIsto vai apagar o histórico local e também o histórico guardado na cloud desta conta. As apostas guardadas não serão apagadas."
    : "Queres mesmo limpar o histórico local?";

  if (!confirm(mensagem)) return;

  const btn = document.getElementById("limparHistorico");
  const textoOriginal = btn ? btn.textContent : "";

  try {
    if (btn) {
      btn.disabled = true;
      btn.textContent = "A limpar...";
    }

    estado.textContent = currentUser
      ? "A limpar histórico local e cloud..."
      : "A limpar histórico local...";

    if (currentUser) {
      const query = supabaseClient
        .from(SUPABASE_HISTORICO)
        .delete()
        .eq("user_id", currentUser.id);

      const { error } = await comTimeout(query, 25000, "limpeza do histórico cloud");
      if (error) throw error;
    }

    historico = [];
    guardarHistoricoLocal();
    renderHistorico();
    atualizarDashboard();
    atualizarContador();

    estado.textContent = currentUser
      ? "Histórico local e cloud limpo."
      : "Histórico local limpo.";

    syncInfo.textContent = `Última sincronização: ${agoraPt()}`;

  } catch (err) {
    console.warn("Não foi possível limpar o histórico na cloud:", err);
    estado.textContent = "Erro ao limpar histórico.";
    alert("Não foi possível limpar o histórico na cloud: " + (err.message || err));

  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = textoOriginal || "Limpar histórico cloud";
    }
  }
}

document.getElementById("loginBtn").addEventListener("click", login);
document.getElementById("signupBtn").addEventListener("click", criarConta);
document.getElementById("resetPasswordBtn").addEventListener("click", recuperarPassword);
document.getElementById("logoutBtn").addEventListener("click", logout);
document.getElementById("syncNowBtn").addEventListener("click", async () => {
  if (syncEmCurso) {
    estado.textContent = "Sincronização já em curso em segundo plano.";
    return;
  }

  const btn = document.getElementById("syncNowBtn");
  const textoOriginal = btn.textContent || "Sincronizar agora";
  syncEmCurso = true;
  btn.disabled = true;
  btn.textContent = "A sincronizar...";
  estado.textContent = "Sincronização iniciada em segundo plano...";
  syncInfo.textContent = "Sincronização em segundo plano...";

  // Liberta a interface rapidamente. A sincronização continua por trás.
  setTimeout(() => {
    btn.disabled = false;
    btn.textContent = textoOriginal;
    if (syncEmCurso) estado.textContent = "Sincronização em segundo plano...";
  }, 1200);

  sincronizarTudo({ verificarDepois: true, background: true })
    .then(() => {
      estado.textContent = "Sincronização concluída.";
      return esperar(1800);
    })
    .catch(err => {
      console.warn("Erro ao sincronizar agora:", err);
      estado.textContent = "Sincronização incompleta. A usar dados disponíveis.";
      return esperar(2500);
    })
    .finally(() => {
      syncEmCurso = false;
      btn.disabled = false;
      btn.textContent = textoOriginal;
      terminarEstadoPronto();
    });
});

authPassword.addEventListener("keydown", e => {
  if (e.key === "Enter") login();
});

jogoSelect.addEventListener("change", () => mudarJogo(jogoSelect.value));
document.getElementById("adicionar").addEventListener("click", adicionarAposta);
const btnGuardarAlias = document.getElementById("guardarAliasBtn");
if (btnGuardarAlias) {
  btnGuardarAlias.addEventListener("click", () => guardarAliasUtilizador());
}
const inputAliasUtilizador = document.getElementById("aliasUtilizador");
if (inputAliasUtilizador) {
  inputAliasUtilizador.addEventListener("keydown", (e) => {
    if (e.key === "Enter") guardarAliasUtilizador();
  });
}

const btnExportarPdfHistorico = document.getElementById("exportarPdfHistorico");
if (btnExportarPdfHistorico) {
  btnExportarPdfHistorico.addEventListener("click", exportarPdfHistorico);
}

const btnPartilharHistorico = document.getElementById("partilharHistorico");
if (btnPartilharHistorico) {
  btnPartilharHistorico.addEventListener("click", () => partilharHistorico());
}

document.getElementById("limparHistorico").addEventListener("click", limparHistorico);

if (pesquisaHistorico) {
  pesquisaHistorico.addEventListener("input", () => {
    textoPesquisaHistorico = pesquisaHistorico.value;
    renderHistorico();
  });
}

if (filtrosHistorico) {
  filtrosHistorico.addEventListener("click", e => {
    const btn = e.target.closest("button[data-filter]");
    if (!btn) return;

    filtroHistorico = btn.dataset.filter;
    filtrosHistorico.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === btn));
    renderHistorico();
  });
}

if (fecharNotificacao) {
  fecharNotificacao.addEventListener("click", () => {
    notificacaoPremio.style.display = "none";
  });
}

// PWA install
let deferredInstallPrompt = null;
const installPwaBtn = document.getElementById("installPwaBtn");

function isPwaInstalada() {
  return window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
}

function isIOS() {
  return /iphone|ipad|ipod/i.test(navigator.userAgent || "");
}

function atualizarBotaoInstalar() {
  if (!installPwaBtn) return;
  installPwaBtn.style.display = !isPwaInstalada() ? "" : "none";
  installPwaBtn.textContent = "Instalar app";
}

function mostrarAjudaInstalacao() {
  const msg = isIOS()
    ? "No iPhone/iPad: toca em Partilhar e depois em Adicionar ao ecrã principal."
    : "No Windows/Edge: usa um perfil normal (não Convidado/InPrivate) e abre ... > Aplicações > Instalar este site como aplicação. No Android/Chrome: menu do browser > Instalar app.";
  estado.textContent = msg;
  alert(msg);
}

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  atualizarBotaoInstalar();
});

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  atualizarBotaoInstalar();
  estado.textContent = "App instalada com sucesso.";
});

if (installPwaBtn) {
  atualizarBotaoInstalar();
  installPwaBtn.addEventListener("click", async () => {
    if (!deferredInstallPrompt) {
      mostrarAjudaInstalacao();
      return;
    }

    deferredInstallPrompt.prompt();
    try {
      const escolha = await deferredInstallPrompt.userChoice;
      estado.textContent = escolha?.outcome === "accepted" ? "Instalação iniciada." : "Instalação cancelada.";
    } catch (e) {
      estado.textContent = "Não foi possível iniciar a instalação automaticamente.";
    }
    deferredInstallPrompt = null;
    atualizarBotaoInstalar();
  });
}

window.addEventListener("online", () => {
  estado.textContent = "Ligação restabelecida. A sincronizar em background...";
  sincronizarTudo({ silencioso: true });
});

window.addEventListener("offline", () => {
  estado.textContent = "Modo offline: a usar dados guardados neste dispositivo.";
});

let novaVersaoDisponivel = false;
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.addEventListener("controllerchange", () => {
    if (novaVersaoDisponivel) return;
    novaVersaoDisponivel = true;
    estado.textContent = "Nova versão instalada. A atualizar...";
    setTimeout(() => location.reload(), 800);
  });
}

supabaseClient.auth.onAuthStateChange(async (event, session) => {
  if (logoutEmCurso) return;
  currentUser = session?.user || null;
  if (currentUser && event !== "INITIAL_SESSION") {
    await arrancarApp();
  }
});

(async function boot() {
  console.log("APP_VERSION", window.APP_VERSION);

  if (new URLSearchParams(window.location.search).has("logout")) {
    try { localStorage.clear(); sessionStorage.clear(); } catch(e) {}
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("service-worker.js?v=26")
      .then(reg => {
        reg.addEventListener("updatefound", () => {
          const novoWorker = reg.installing;
          if (!novoWorker) return;
          novoWorker.addEventListener("statechange", () => {
            if (novoWorker.state === "installed" && navigator.serviceWorker.controller) {
              estado.textContent = "Nova versão disponível. A aplicar atualização...";
              novoWorker.postMessage({ type: "SKIP_WAITING" });
            }
          });
        });
      })
      .catch(err => console.warn("Service worker indisponível:", err));
  }

  const { data, error } = await supabaseClient.auth.getSession();
  if (error) console.warn(error);

  currentUser = data?.session?.user || null;

  if (currentUser) {
    await arrancarApp();
  } else {
    authBox.style.display = "";
    userBox.style.display = "none";
    appBox.style.display = "none";
    estado.textContent = "Inicia sessão para continuar.";
  }
})();









setTimeout(() => { try { iniciarNotificacoesV34(); atualizarEstatisticasAvancadas(); notificarPremiosSeNecessarioV34(); } catch(e) {} }, 500);
window.__statsV33Interval = setInterval(() => { try { atualizarEstatisticasAvancadas(); notificarPremiosSeNecessarioV34(); } catch(e) {} }, 2000);
document.addEventListener("click", () => { setTimeout(() => { try { atualizarEstatisticasAvancadas(); } catch(e) {} }, 150); });


// V34 - Notificações PWA
const VAPID_PUBLIC_KEY = ""; // Futuro: chave pública VAPID para push real via servidor.

function atualizarEstadoNotificacoesV34(msg = "") {
  const btn = document.getElementById("ativarNotificacoesBtn");
  const estadoEl = document.getElementById("notificacoesEstado");
  const suportado = "Notification" in window && "serviceWorker" in navigator;
  const perm = suportado ? Notification.permission : "unsupported";
  const ativo = localStorage.getItem("jsc_notificacoes") === "1" && perm === "granted";

  if (btn) {
    if (!suportado) {
      btn.textContent = "🔕 Sem suporte";
      btn.disabled = true;
    } else if (ativo) {
      btn.textContent = "🔔 Ativas";
      btn.classList.add("ativo");
      btn.disabled = false;
    } else if (perm === "denied") {
      btn.textContent = "🔕 Bloqueadas";
      btn.classList.remove("ativo");
      btn.disabled = false;
    } else {
      btn.textContent = "🔔 Notificações";
      btn.classList.remove("ativo");
      btn.disabled = false;
    }
  }

  if (estadoEl && msg) {
    estadoEl.textContent = msg;
    estadoEl.classList.add("visivel");
    clearTimeout(window.__notificacoesEstadoTimer);
    window.__notificacoesEstadoTimer = setTimeout(() => {
      estadoEl.textContent = "";
      estadoEl.classList.remove("visivel");
    }, 4500);
  }
}

function urlBase64ParaUint8ArrayV34(base64String) {
  const padding = "=".repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

async function obterServiceWorkerProntoV34() {
  if (!("serviceWorker" in navigator)) return null;
  try { return await navigator.serviceWorker.ready; }
  catch {
    try { return await navigator.serviceWorker.register("./service-worker.js"); }
    catch { return null; }
  }
}

async function guardarSubscricaoPushV34(subscription) {
  if (!subscription) return;
  localStorage.setItem("jsc_push_subscription", JSON.stringify(subscription));
  try {
    if (typeof supabaseClient !== "undefined" && supabaseClient && currentUser) {
      await supabaseClient.from("push_subscriptions").upsert({
        user_id: currentUser.id,
        subscription,
        user_agent: navigator.userAgent,
        atualizado_em: new Date().toISOString()
      }, { onConflict: "user_id" });
    }
  } catch {}
}

async function subscreverPushSePossivelV34(reg) {
  if (!reg || !("PushManager" in window)) return null;
  try {
    let sub = await reg.pushManager.getSubscription();
    if (!sub && VAPID_PUBLIC_KEY) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ParaUint8ArrayV34(VAPID_PUBLIC_KEY)
      });
    }
    if (sub) await guardarSubscricaoPushV34(sub);
    return sub;
  } catch { return null; }
}

async function mostrarNotificacaoLocalV34(titulo, opcoes = {}) {
  if (!("Notification" in window) || Notification.permission !== "granted") return false;
  const reg = await obterServiceWorkerProntoV34();
  const options = {
    body: opcoes.body || "",
    icon: opcoes.icon || "./icon-192.png",
    badge: opcoes.badge || "./icon-192.png",
    tag: opcoes.tag || "jsc-notificacao",
    renotify: true,
    data: { url: "./", ...(opcoes.data || {}) }
  };
  try {
    if (reg && reg.showNotification) await reg.showNotification(titulo, options);
    else new Notification(titulo, options);
    return true;
  } catch { return false; }
}

async function pedirPermissaoNotificacoesV34() {
  if (!("Notification" in window)) { alert("Este browser não suporta notificações."); return; }
  if (!window.isSecureContext) { alert("As notificações precisam de HTTPS."); return; }
  const perm = await Notification.requestPermission();
  if (perm !== "granted") {
    localStorage.setItem("jsc_notificacoes", "0");
    atualizarEstadoNotificacoesV34(perm === "denied" ? "Notificações bloqueadas. Ativa-as nas definições do browser." : "Notificações não ativadas.");
    return;
  }
  localStorage.setItem("jsc_notificacoes", "1");
  const reg = await obterServiceWorkerProntoV34();
  await subscreverPushSePossivelV34(reg);
  atualizarEstadoNotificacoesV34("Notificações ativas neste dispositivo.");
  await mostrarNotificacaoLocalV34("Notificações ativas 🍀", {
    body: "Vais receber alertas quando a app encontrar prémios.",
    tag: "jsc-notificacoes-ativas"
  });
}

function notificarPremiosSeNecessarioV34() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  if (localStorage.getItem("jsc_notificacoes") !== "1") return;
  let historicoLista = [];
  try {
    if (typeof recolherHistoricoV33 === "function") historicoLista = recolherHistoricoV33();
    else if (typeof recolherHistoricoV32 === "function") historicoLista = recolherHistoricoV32();
  } catch {}
  const totalPremios = historicoLista.length;
  const ultimoAvisado = Number(localStorage.getItem("jsc_premios_notificados") || "0");
  if (totalPremios > ultimoAvisado) {
    const ultimo = historicoLista[0] || historicoLista[historicoLista.length - 1] || {};
    const jogo = (typeof obterCampoJogoPremioV33 === "function" ? obterCampoJogoPremioV33(ultimo) : (ultimo.jogo || ultimo.titulo || ""));
    const jogoTxt = (typeof formatarJogoV33 === "function" ? formatarJogoV33(jogo) : (jogo || "Jogo"));
    mostrarNotificacaoLocalV34("🎉 Prémio encontrado!", {
      body: `${jogoTxt}: ${ultimo.premio || "prémio registado"}`,
      tag: `jsc-premio-${totalPremios}`
    });
    localStorage.setItem("jsc_premios_notificados", String(totalPremios));
  }
}

function iniciarNotificacoesV34() {
  const btn = document.getElementById("ativarNotificacoesBtn");
  atualizarEstadoNotificacoesV34();
  if (btn && !btn.__notificacoesV34) {
    btn.__notificacoesV34 = true;
    btn.addEventListener("click", () => pedirPermissaoNotificacoesV34());
  }
}



// V35 - Cartão de notificações com clique real
function atualizarCartaoNotificacoesV35(msg = "") {
  const suporta = "Notification" in window && "serviceWorker" in navigator;
  const permissao = suporta ? Notification.permission : "unsupported";
  const ativo = localStorage.getItem("jsc_notificacoes") === "1" && permissao === "granted";
  const ultima = localStorage.getItem("jsc_ultima_notificacao") || "";

  const badge = document.getElementById("notifEstadoBadge");
  const permEl = document.getElementById("notifPermissao");
  const ultimaEl = document.getElementById("notifUltima");
  const msgEl = document.getElementById("notifMensagem");
  const btnHeader = document.getElementById("ativarNotificacoesBtn");

  if (permEl) permEl.textContent = permissao;
  if (ultimaEl) ultimaEl.textContent = ultima ? new Date(ultima).toLocaleString("pt-PT") : "—";

  if (badge) {
    if (!suporta) badge.textContent = "🔕 Sem suporte";
    else if (ativo) badge.textContent = "🟢 Ativas";
    else if (permissao === "denied") badge.textContent = "🔴 Bloqueadas";
    else badge.textContent = "🟡 Não autorizadas";
  }

  if (btnHeader) {
    btnHeader.textContent = ativo ? "🔔 Ativas" : "🔔 Notificações";
    btnHeader.classList.toggle("ativo", ativo);
  }

  if (msgEl && msg) {
    msgEl.textContent = msg;
    msgEl.classList.add("visivel");
    clearTimeout(window.__notifMsgTimer);
    window.__notifMsgTimer = setTimeout(() => {
      msgEl.textContent = "";
      msgEl.classList.remove("visivel");
    }, 5000);
  }
}

async function obterServiceWorkerV35() {
  if (!("serviceWorker" in navigator)) return null;
  try {
    return await navigator.serviceWorker.ready;
  } catch {
    try {
      return await navigator.serviceWorker.register("./service-worker.js");
    } catch {
      return null;
    }
  }
}

async function enviarNotificacaoTesteV35() {
  if (!("Notification" in window)) {
    alert("Este browser não suporta notificações.");
    return;
  }

  if (Notification.permission !== "granted") {
    atualizarCartaoNotificacoesV35("Primeiro carrega em Ativar notificações.");
    return;
  }

  const reg = await obterServiceWorkerV35();
  const options = {
    body: "As notificações estão configuradas com sucesso.",
    icon: "./icon-192.png",
    badge: "./icon-192.png",
    tag: "jsc-teste",
    data: { url: "./" }
  };

  try {
    if (reg && reg.showNotification) await reg.showNotification("🍀 Jogos Santa Casa", options);
    else new Notification("🍀 Jogos Santa Casa", options);

    localStorage.setItem("jsc_ultima_notificacao", new Date().toISOString());
    atualizarCartaoNotificacoesV35("Notificação de teste enviada.");
  } catch {
    atualizarCartaoNotificacoesV35("Não foi possível enviar a notificação.");
  }
}

async function ativarNotificacoesV35() {
  if (!("Notification" in window)) {
    alert("Este browser não suporta notificações.");
    return;
  }

  if (!window.isSecureContext) {
    alert("As notificações precisam de HTTPS.");
    return;
  }

  const permissao = await Notification.requestPermission();

  if (permissao === "granted") {
    localStorage.setItem("jsc_notificacoes", "1");
    await obterServiceWorkerV35();
    atualizarCartaoNotificacoesV35("Notificações ativadas neste dispositivo.");
    await enviarNotificacaoTesteV35();
  } else {
    localStorage.setItem("jsc_notificacoes", "0");
    atualizarCartaoNotificacoesV35(
      permissao === "denied"
        ? "Notificações bloqueadas. Ativa-as nas definições do browser."
        : "Notificações não ativadas."
    );
  }
}

function iniciarCartaoNotificacoesV35() {
  const ativar = document.getElementById("notifAtivarBtn");
  const teste = document.getElementById("notifTesteBtn");
  const header = document.getElementById("ativarNotificacoesBtn");

  if (ativar && !ativar.__v35) {
    ativar.__v35 = true;
    ativar.addEventListener("click", ativarNotificacoesV35);
  }

  if (teste && !teste.__v35) {
    teste.__v35 = true;
    teste.addEventListener("click", enviarNotificacaoTesteV35);
  }

  if (header && !header.__v35) {
    header.__v35 = true;
    header.addEventListener("click", ativarNotificacoesV35);
  }

  atualizarCartaoNotificacoesV35();
}


setTimeout(() => {
  try { iniciarCartaoNotificacoesV35(); } catch(e) {}
}, 700);


// V36 - Banner inteligente de notificações
function deveMostrarBannerNotificacoesV36() {
  const suporta = "Notification" in window && "serviceWorker" in navigator;
  if (!suporta) return false;
  if (Notification.permission === "granted") return false;
  if (Notification.permission === "denied") return false;

  const adiadoAte = Number(localStorage.getItem("jsc_notif_banner_adiado_ate") || "0");
  if (adiadoAte && Date.now() < adiadoAte) return false;

  return true;
}

function atualizarBannerNotificacoesV36() {
  const banner = document.getElementById("notifBanner");
  if (!banner) return;

  const mostrar = deveMostrarBannerNotificacoesV36();
  banner.hidden = !mostrar;
  banner.classList.toggle("visivel", mostrar);
}

function adiarBannerNotificacoesV36() {
  // Esconde durante 7 dias.
  localStorage.setItem("jsc_notif_banner_adiado_ate", String(Date.now() + 7 * 24 * 60 * 60 * 1000));
  atualizarBannerNotificacoesV36();
}

async function ativarNotificacoesPeloBannerV36() {
  if (typeof ativarNotificacoesV35 === "function") {
    await ativarNotificacoesV37();
  } else if (typeof pedirPermissaoNotificacoes === "function") {
    await ativarNotificacoesV37();
  }

  if ("Notification" in window && Notification.permission === "granted") {
    localStorage.removeItem("jsc_notif_banner_adiado_ate");
  }

  atualizarBannerNotificacoesV36();

  if (typeof atualizarCartaoNotificacoesV35 === "function") {
    atualizarCartaoNotificacoesV35();
  }
}

function iniciarBannerNotificacoesV36() {
  const ativar = document.getElementById("notifBannerAtivarBtn");
  const maisTarde = document.getElementById("notifBannerMaisTardeBtn");

  if (ativar && !ativar.__v36) {
    ativar.__v36 = true;
    ativar.addEventListener("click", ativarNotificacoesPeloBannerV36);
  }

  if (maisTarde && !maisTarde.__v36) {
    maisTarde.__v36 = true;
    maisTarde.addEventListener("click", adiarBannerNotificacoesV36);
  }

  atualizarBannerNotificacoesV36();
}


setTimeout(() => {
  try { iniciarBannerNotificacoesV36(); } catch(e) {}
}, 900);
document.addEventListener("visibilitychange", () => {
  try { atualizarBannerNotificacoesV36(); } catch(e) {}
});


// V37 - Notificações limpas + tipos: prémios, novos resultados e sorteios
const JSC_NOTIF_TYPES_V37 = {
  premios: true,
  resultados: true,
  sorteios: true
};

function notifSuportadasV37() {
  return "Notification" in window && "serviceWorker" in navigator && window.isSecureContext;
}

function estadoNotificacoesV37() {
  if (!notifSuportadasV37()) return "unsupported";
  if (Notification.permission === "granted" && localStorage.getItem("jsc_notificacoes") === "1") return "granted";
  return Notification.permission;
}

function textoEstadoNotificacoesV37() {
  const estado = estadoNotificacoesV37();
  if (estado === "granted") return "🟢 Notificações ativas";
  if (estado === "denied") return "🔴 Notificações bloqueadas";
  if (estado === "unsupported") return "🔕 Sem suporte";
  return "🟡 Notificações desativadas";
}

function atualizarMiniNotificacoesV37(msg = "") {
  const mini = document.getElementById("notifStatusMini");
  const headerBtn = document.getElementById("ativarNotificacoesBtn");
  const estado = estadoNotificacoesV37();

  const texto = estado === "granted" ? "🟢 Notificações ativas" :
    estado === "denied" ? "🔴 Notificações bloqueadas" :
    estado === "unsupported" ? "🔕 Sem notificações" :
    "🟡 Notificações desativadas";

  if (mini) {
    mini.textContent = texto;
    mini.classList.toggle("ativo", estado === "granted");
    mini.classList.toggle("bloqueado", estado === "denied" || estado === "unsupported");
  }

  if (headerBtn) {
    headerBtn.textContent = estado === "granted" ? "🔔 Ativas" : "🔔 Notificações";
    headerBtn.classList.toggle("ativo", estado === "granted");
  }

  atualizarModalNotificacoesV37(msg);
}

function atualizarModalNotificacoesV37(msg = "") {
  const estadoEl = document.getElementById("notifModalEstado");
  const permEl = document.getElementById("notifModalPermissao");
  const ultimaEl = document.getElementById("notifModalUltima");
  const msgEl = document.getElementById("notifModalMsg");
  const ultima = localStorage.getItem("jsc_ultima_notificacao") || "";

  if (estadoEl) estadoEl.textContent = textoEstadoNotificacoesV37();
  if (permEl) permEl.textContent = notifSuportadasV37() ? Notification.permission : "unsupported";
  if (ultimaEl) ultimaEl.textContent = ultima ? new Date(ultima).toLocaleString("pt-PT") : "—";

  if (msgEl && msg) {
    msgEl.textContent = msg;
    msgEl.classList.add("visivel");
    clearTimeout(window.__notifModalMsgTimer);
    window.__notifModalMsgTimer = setTimeout(() => {
      msgEl.textContent = "";
      msgEl.classList.remove("visivel");
    }, 4500);
  }
}

function abrirModalNotificacoesV37() {
  const modal = document.getElementById("notifModal");
  if (!modal) return;
  modal.hidden = false;
  atualizarModalNotificacoesV37();
}

function fecharModalNotificacoesV37() {
  const modal = document.getElementById("notifModal");
  if (modal) modal.hidden = true;
}

async function obterServiceWorkerV37() {
  if (!("serviceWorker" in navigator)) return null;
  try {
    return await navigator.serviceWorker.ready;
  } catch {
    try { return await navigator.serviceWorker.register("./service-worker.js"); }
    catch { return null; }
  }
}

async function enviarNotificacaoV37(titulo, body, tag = "jsc-notificacao") {
  if (!notifSuportadasV37() || Notification.permission !== "granted") return false;

  const reg = await obterServiceWorkerV37();
  const options = {
    body,
    icon: "./icon-192.png",
    badge: "./icon-192.png",
    tag,
    renotify: true,
    data: { url: "./" }
  };

  try {
    if (reg && reg.showNotification) await reg.showNotification(titulo, options);
    else new Notification(titulo, options);
    localStorage.setItem("jsc_ultima_notificacao", new Date().toISOString());
    atualizarMiniNotificacoesV37();
    return true;
  } catch {
    return false;
  }
}

async function enviarNotificacaoTesteV37() {
  if (estadoNotificacoesV37() !== "granted") {
    atualizarMiniNotificacoesV37("Primeiro ativa as notificações.");
    return;
  }
  const ok = await enviarNotificacaoV37("🍀 Jogos Santa Casa", "Teste enviado com sucesso. As notificações estão prontas.", "jsc-teste");
  atualizarMiniNotificacoesV37(ok ? "Notificação de teste enviada." : "Não foi possível enviar a notificação.");
}

async function ativarNotificacoesV37() {
  if (!notifSuportadasV37()) {
    atualizarMiniNotificacoesV37("As notificações precisam de HTTPS e de browser compatível.");
    return;
  }

  const permissao = await Notification.requestPermission();

  if (permissao === "granted") {
    localStorage.setItem("jsc_notificacoes", "1");
    localStorage.removeItem("jsc_notif_banner_adiado_ate");
    await obterServiceWorkerV37();
    atualizarBannerNotificacoesV36?.();
    atualizarMiniNotificacoesV37("Notificações ativadas neste dispositivo.");
    await enviarNotificacaoV37("Notificações ativas 🍀", "Vais receber alertas de prémios, novos resultados e sorteios.", "jsc-ativas");
  } else {
    localStorage.setItem("jsc_notificacoes", "0");
    atualizarMiniNotificacoesV37(permissao === "denied"
      ? "Notificações bloqueadas. Ativa-as nas definições do browser."
      : "Notificações não ativadas.");
  }
}

// Compatibilidade com versões anteriores / banner
async function ativarNotificacoesV35(){ return ativarNotificacoesV37(); }
async function pedirPermissaoNotificacoes(){ return ativarNotificacoesV37(); }
async function enviarNotificacaoTesteV35(){ return enviarNotificacaoTesteV37(); }

function obterHistoricoParaNotifV37() {
  try { if (typeof recolherHistoricoV33 === "function") return recolherHistoricoV33() || []; } catch {}
  try { if (typeof recolherHistoricoV32 === "function") return recolherHistoricoV32() || []; } catch {}
  try { if (Array.isArray(historico)) return historico; } catch {}
  try {
    const p = JSON.parse(localStorage.getItem("historico") || localStorage.getItem("jsc_historico") || "[]");
    return Array.isArray(p) ? p : [];
  } catch { return []; }
}

function jogoPremioNotifV37(item) {
  try {
    const campo = typeof obterCampoJogoPremioV33 === "function" ? obterCampoJogoPremioV33(item) : (item?.jogo || item?.titulo || item?.descricao || "");
    return typeof formatarJogoV33 === "function" ? formatarJogoV33(campo) : (campo || "Jogo");
  } catch {
    return item?.jogo || "Jogo";
  }
}

function assinaturaResultadosV37() {
  const partes = [];
  try {
    const jogos = ["euromilhoes", "totoloto", "eurodreams", "milhao", "lotaria_classica", "lotaria_popular"];
    jogos.forEach(j => {
      const r = (typeof resultadosOficiais !== "undefined" && resultadosOficiais) ? resultadosOficiais[j] : null;
      if (r) partes.push(`${j}:${r.sorteio || ""}:${r.data || r.data_sorteio || ""}:${r.numeros || ""}:${r.extras || ""}:${r.codigo || ""}`);
    });
  } catch {}
  return partes.join("|");
}

async function verificarNotificacoesPremiosV37() {
  if (estadoNotificacoesV37() !== "granted" || !JSC_NOTIF_TYPES_V37.premios) return;
  const hist = obterHistoricoParaNotifV37();
  const total = hist.length;
  const avisado = Number(localStorage.getItem("jsc_premios_notificados") || "0");
  if (total > avisado) {
    const ultimo = hist[0] || hist[hist.length - 1] || {};
    await enviarNotificacaoV37("🎉 Prémio encontrado!", `${jogoPremioNotifV37(ultimo)}: ${ultimo.premio || "prémio registado"}`, `jsc-premio-${total}`);
    localStorage.setItem("jsc_premios_notificados", String(total));
  }
}

async function verificarNotificacoesResultadosV37() {
  if (estadoNotificacoesV37() !== "granted" || !JSC_NOTIF_TYPES_V37.resultados) return;
  const assinatura = assinaturaResultadosV37();
  if (!assinatura) return;

  const anterior = localStorage.getItem("jsc_assinatura_resultados") || "";
  if (anterior && anterior !== assinatura) {
    await enviarNotificacaoV37("📢 Novos resultados disponíveis", "Já existem resultados atualizados para verificar as tuas apostas.", "jsc-novos-resultados");
  }
  localStorage.setItem("jsc_assinatura_resultados", assinatura);
}

function jogosComSorteioHojeV37() {
  const d = new Date();
  const dia = d.getDay(); // 0 dom, 1 seg, 2 ter, 3 qua, 4 qui, 5 sex, 6 sab
  const jogos = [];
  if (dia === 2 || dia === 5) jogos.push("Euromilhões");
  if (dia === 3 || dia === 6) jogos.push("Totoloto");
  if ([1,2,3,4,5,6].includes(dia)) jogos.push("M1lhão");
  return jogos;
}

async function verificarNotificacoesSorteiosV37() {
  if (estadoNotificacoesV37() !== "granted" || !JSC_NOTIF_TYPES_V37.sorteios) return;

  const hoje = new Date().toISOString().slice(0,10);
  const key = `jsc_sorteio_avisado_${hoje}`;
  if (localStorage.getItem(key) === "1") return;

  const jogos = jogosComSorteioHojeV37();
  if (!jogos.length) return;

  // Só avisa a partir das 10h para não chatear de madrugada.
  if (new Date().getHours() < 10) return;

  await enviarNotificacaoV37("🎲 Hoje há sorteio", `${jogos.join(", ")}. Boa sorte! 🍀`, "jsc-sorteio-hoje");
  localStorage.setItem(key, "1");
}

async function executarNotificacoesAutomaticasV37() {
  await verificarNotificacoesPremiosV37();
  await verificarNotificacoesResultadosV37();
  await verificarNotificacoesSorteiosV37();
}

function iniciarNotificacoesCleanV37() {
  const mini = document.getElementById("notifStatusMini");
  const fechar = document.getElementById("notifModalFechar");
  const fecharBg = document.getElementById("notifModalFecharBg");
  const ativar = document.getElementById("notifModalAtivar");
  const teste = document.getElementById("notifModalTeste");
  const header = document.getElementById("ativarNotificacoesBtn");

  if (mini && !mini.__v37) { mini.__v37 = true; mini.addEventListener("click", abrirModalNotificacoesV37); }
  if (fechar && !fechar.__v37) { fechar.__v37 = true; fechar.addEventListener("click", fecharModalNotificacoesV37); }
  if (fecharBg && !fecharBg.__v37) { fecharBg.__v37 = true; fecharBg.addEventListener("click", fecharModalNotificacoesV37); }
  if (ativar && !ativar.__v37) { ativar.__v37 = true; ativar.addEventListener("click", ativarNotificacoesV37); }
  if (teste && !teste.__v37) { teste.__v37 = true; teste.addEventListener("click", enviarNotificacaoTesteV37); }
  if (header && !header.__v37) { header.__v37 = true; header.addEventListener("click", ativarNotificacoesV37); }

  atualizarMiniNotificacoesV37();
  executarNotificacoesAutomaticasV37();
}


setTimeout(() => {
  try { iniciarNotificacoesCleanV37(); } catch(e) {}
}, 900);
setInterval(() => {
  try { executarNotificacoesAutomaticasV37(); } catch(e) {}
}, 60000);
