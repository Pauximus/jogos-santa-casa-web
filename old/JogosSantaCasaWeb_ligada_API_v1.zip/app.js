const API = "https://jogos-santa-casa-api.onrender.com";

const jogos = {
  euromilhoes: { nome: "Euromilhões", numeros: 5, extras: 2, extraLabel: "⭐", tab: "EUROMILHÕES" },
  totoloto: { nome: "Totoloto", numeros: 5, extras: 1, extraLabel: "Nº da Sorte", tab: "totoloto", offline: true },
  eurodreams: { nome: "EuroDreams", numeros: 6, extras: 1, extraLabel: "Nº de Sonho", tab: "EURO★DREAMS", offline: true },
  milhao: { nome: "M1lhão", codigo: true, tab: "M1LHÃO", offline: true },
  lotaria_classica: { nome: "Lotaria Clássica", lotaria: true, tab: "lotaria clássica", offline: true },
  lotaria_popular: { nome: "Lotaria Popular", lotaria: true, tab: "lotaria popular", offline: true }
};

const jogoSelect = document.getElementById("jogo");
const tabs = document.getElementById("tabs");
const camposDiv = document.getElementById("campos");
const listaApostas = document.getElementById("lista-apostas");
const resultado = document.getElementById("resultado");
const estado = document.getElementById("estado");

let jogoAtual = "euromilhoes";
let apostas = JSON.parse(localStorage.getItem("apostasJSC") || "{}");
for (const key of Object.keys(jogos)) if (!apostas[key]) apostas[key] = [];

function guardar(){ localStorage.setItem("apostasJSC", JSON.stringify(apostas)); }

function init(){
  for (const [key,cfg] of Object.entries(jogos)){
    const opt=document.createElement("option"); opt.value=key; opt.textContent=cfg.nome; jogoSelect.appendChild(opt);
    const tab=document.createElement("button"); tab.className="tab "+key; tab.textContent=cfg.tab; tab.dataset.jogo=key; tab.onclick=()=>mudarJogo(key); tabs.appendChild(tab);
  }
  mudarJogo(jogoAtual);
}

function mudarJogo(key){
  jogoAtual=key; jogoSelect.value=key;
  document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.jogo===key));
  renderCampos(); renderLista(); verificar();
}

function renderCampos(){
  const cfg=jogos[jogoAtual]; camposDiv.innerHTML="";
  if(cfg.codigo){ camposDiv.innerHTML='<label>Código:</label><input id="codigo" class="large" placeholder="ABC 12345">'; return; }
  if(cfg.lotaria){ camposDiv.innerHTML='<label>Número:</label><input id="numeroLotaria" class="large" placeholder="Número">'; return; }
  for(let i=1;i<=cfg.numeros;i++) camposDiv.insertAdjacentHTML("beforeend",`<label>Nº${i}:</label><input class="num" inputmode="numeric">`);
  camposDiv.insertAdjacentHTML("beforeend","<strong> + </strong>");
  for(let i=1;i<=cfg.extras;i++){ const label=cfg.extraLabel==="⭐"?`⭐ ${i}`:cfg.extraLabel; camposDiv.insertAdjacentHTML("beforeend",`<label>${label}:</label><input class="extra" inputmode="numeric">`); }
}

function normalizarAposta(){
  const cfg=jogos[jogoAtual];
  if(cfg.codigo) return document.getElementById("codigo").value.trim().toUpperCase().replace(/\s+/g," ");
  if(cfg.lotaria) return document.getElementById("numeroLotaria").value.replace(/\D/g,"").padStart(5,"0");
  const nums=[...document.querySelectorAll(".num")].map(i=>i.value.trim());
  const extras=[...document.querySelectorAll(".extra")].map(i=>i.value.trim());
  if(nums.some(v=>!v)||extras.some(v=>!v)){ alert("Preenche todos os campos."); return ""; }
  return nums.map(Number).sort((a,b)=>a-b).join(" ")+" + "+extras.map(Number).sort((a,b)=>a-b).join(" ");
}

function parseAposta(aposta){
  const [numsTxt, extrasTxt]=aposta.split("+");
  return { nums: numsTxt.trim().split(/\s+/).map(Number), extras: extrasTxt.trim().split(/\s+/).map(Number) };
}

function renderLista(){
  listaApostas.innerHTML="";
  apostas[jogoAtual].forEach((aposta,index)=>{
    const li=document.createElement("li"); li.textContent=`${index+1}) ${aposta}`;
    const btn=document.createElement("button"); btn.className="delete"; btn.textContent="Apagar";
    btn.onclick=()=>{ apostas[jogoAtual].splice(index,1); guardar(); renderLista(); verificar(); };
    li.appendChild(btn); listaApostas.appendChild(li);
  });
}

function adicionarAposta(){
  const aposta=normalizarAposta(); if(!aposta) return;
  if(apostas[jogoAtual].includes(aposta)){ alert("Essa aposta já existe."); return; }
  apostas[jogoAtual].push(aposta); guardar(); renderCampos(); renderLista(); verificar();
}

async function verificar(){
  const cfg=jogos[jogoAtual]; estado.textContent="A obter resultados...";
  if(cfg.offline){
    resultado.innerHTML=`<div class="result-title">${cfg.nome.toUpperCase()}</div><div class="result-card warn">Este jogo ainda não está ligado à API. Próxima fase.</div><div>Apostas guardadas: ${apostas[jogoAtual].length}</div>`;
    estado.textContent=`${cfg.nome}: ${apostas[jogoAtual].length} aposta(s)`; return;
  }
  try{
    const res=await fetch(`${API}/euromilhoes`);
    const data=await res.json();
    if(data.erro) throw new Error(data.erro);
    const numeros=data.numeros.split(/\s+/).map(Number);
    const estrelas=data.estrelas.split(/\s+/).map(Number);
    let html=`<div class="result-title">EUROMILHÕES</div><div>Resultado: [${numeros.join(", ")}] + [${estrelas.join(", ")}]</div>`;
    apostas.euromilhoes.forEach((aposta,index)=>{
      const {nums,extras}=parseAposta(aposta);
      const acertosNums=nums.filter(n=>numeros.includes(n)).length;
      const acertosExtras=extras.filter(e=>estrelas.includes(e)).length;
      const comAcertos=acertosNums||acertosExtras;
      html+=`<div class="result-card ${comAcertos?"warn":"bad"}"><strong>${comAcertos?"🟡 COM ACERTOS":"🔴 SEM PRÉMIO"}</strong><br>Aposta ${index+1}: ${aposta}<br>Acertos: ${acertosNums} número(s) + ${acertosExtras} estrela(s)</div>`;
    });
    resultado.innerHTML=html; estado.textContent=`Euromilhões: ${apostas.euromilhoes.length} aposta(s)`;
  }catch(err){
    resultado.innerHTML=`<div class="result-card bad">Erro ao obter resultados: ${err.message}</div>`; estado.textContent="Erro.";
  }
}

jogoSelect.addEventListener("change",()=>mudarJogo(jogoSelect.value));
document.getElementById("adicionar").addEventListener("click",adicionarAposta);
document.getElementById("atualizar").addEventListener("click",verificar);
if("serviceWorker" in navigator) navigator.serviceWorker.register("service-worker.js");
init();
