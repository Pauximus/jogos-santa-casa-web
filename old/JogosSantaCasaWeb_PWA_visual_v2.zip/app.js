const jogos = {
  euromilhoes: { nome: "Euromilhões", numeros: 5, extras: 2, extraLabel: "⭐", tab: "EUROMILHÕES" },
  totoloto: { nome: "Totoloto", numeros: 5, extras: 1, extraLabel: "Nº da Sorte", tab: "totoloto" },
  eurodreams: { nome: "EuroDreams", numeros: 6, extras: 1, extraLabel: "Nº de Sonho", tab: "EURO★DREAMS" },
  milhao: { nome: "M1lhão", codigo: true, tab: "M1LHÃO" },
  lotaria_classica: { nome: "Lotaria Clássica", lotaria: true, tab: "lotaria clássica" },
  lotaria_popular: { nome: "Lotaria Popular", lotaria: true, tab: "lotaria popular" }
};

const jogoSelect = document.getElementById("jogo");
const tabs = document.getElementById("tabs");
const camposDiv = document.getElementById("campos");
const listaApostas = document.getElementById("lista-apostas");
const resultado = document.getElementById("resultado");
const estado = document.getElementById("estado");

let jogoAtual = "euromilhoes";
let apostas = JSON.parse(localStorage.getItem("apostasJSC") || "{}");

for (const key of Object.keys(jogos)) {
  if (!apostas[key]) apostas[key] = [];
}

function guardar() {
  localStorage.setItem("apostasJSC", JSON.stringify(apostas));
}

function init() {
  for (const [key, cfg] of Object.entries(jogos)) {
    const opt = document.createElement("option");
    opt.value = key;
    opt.textContent = cfg.nome;
    jogoSelect.appendChild(opt);

    const tab = document.createElement("button");
    tab.className = "tab " + key;
    tab.textContent = cfg.tab;
    tab.onclick = () => mudarJogo(key);
    tab.dataset.jogo = key;
    tabs.appendChild(tab);
  }

  mudarJogo(jogoAtual);
}

function mudarJogo(key) {
  jogoAtual = key;
  jogoSelect.value = key;
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.jogo === key));
  renderCampos();
  renderLista();
  verificarTeste();
}

function renderCampos() {
  const cfg = jogos[jogoAtual];
  camposDiv.innerHTML = "";

  if (cfg.codigo) {
    camposDiv.innerHTML = `<label>Código:</label><input id="codigo" class="large" placeholder="ABC 12345">`;
    return;
  }

  if (cfg.lotaria) {
    camposDiv.innerHTML = `<label>Número:</label><input id="numeroLotaria" class="large" placeholder="Número">`;
    return;
  }

  for (let i = 1; i <= cfg.numeros; i++) {
    camposDiv.insertAdjacentHTML("beforeend", `<label>Nº${i}:</label><input class="num" inputmode="numeric">`);
  }

  camposDiv.insertAdjacentHTML("beforeend", `<strong> + </strong>`);

  for (let i = 1; i <= cfg.extras; i++) {
    camposDiv.insertAdjacentHTML("beforeend", `<label>${cfg.extraLabel}${cfg.extraLabel === "⭐" ? " " + i : ""}:</label><input class="extra" inputmode="numeric">`);
  }
}

function normalizarAposta() {
  const cfg = jogos[jogoAtual];

  if (cfg.codigo) {
    return document.getElementById("codigo").value.trim().toUpperCase().replace(/\s+/g, " ");
  }

  if (cfg.lotaria) {
    return document.getElementById("numeroLotaria").value.replace(/\D/g, "").padStart(5, "0");
  }

  const nums = [...document.querySelectorAll(".num")].map(i => i.value.trim());
  const extras = [...document.querySelectorAll(".extra")].map(i => i.value.trim());

  if (nums.some(v => !v) || extras.some(v => !v)) {
    alert("Preenche todos os campos.");
    return "";
  }

  return nums.map(Number).sort((a,b) => a-b).join(" ") + " + " + extras.map(Number).sort((a,b) => a-b).join(" ");
}

function renderLista() {
  listaApostas.innerHTML = "";

  apostas[jogoAtual].forEach((aposta, index) => {
    const li = document.createElement("li");
    li.textContent = `${index + 1}) ${aposta}`;

    const btn = document.createElement("button");
    btn.className = "delete";
    btn.textContent = "Apagar";
    btn.onclick = () => {
      apostas[jogoAtual].splice(index, 1);
      guardar();
      renderLista();
      verificarTeste();
    };

    li.appendChild(btn);
    listaApostas.appendChild(li);
  });
}

function adicionarAposta() {
  const aposta = normalizarAposta();
  if (!aposta) return;

  if (apostas[jogoAtual].includes(aposta)) {
    alert("Essa aposta já existe.");
    return;
  }

  apostas[jogoAtual].push(aposta);
  guardar();
  renderCampos();
  renderLista();
  verificarTeste();
}

function verificarTeste() {
  const cfg = jogos[jogoAtual];
  const total = apostas[jogoAtual].length;

  resultado.innerHTML = `
    <div class="result-block">
      <div class="result-title">${cfg.nome.toUpperCase()}</div>
      <div>Sorteio: último sorteio</div>
      <div>Resultado: ligação oficial na próxima fase</div>
      <div class="result-card warn">Apostas guardadas: ${total}</div>
      <div class="result-card bad">Esta versão já está com visual aproximado ao Windows. Falta ligar resultados oficiais.</div>
    </div>
  `;

  estado.textContent = `${cfg.nome}: ${total} aposta(s) guardada(s)`;
}

jogoSelect.addEventListener("change", () => mudarJogo(jogoSelect.value));
document.getElementById("adicionar").addEventListener("click", adicionarAposta);

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("service-worker.js");
}

init();
